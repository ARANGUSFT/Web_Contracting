@extends('layouts.app')

@section('content')

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    :root {
        --slate-900: #0f172a;
        --slate-800: #1e293b;
        --slate-700: #334155;
        --slate-600: #475569;
        --slate-400: #94a3b8;
        --slate-300: #cbd5e1;
        --slate-200: #e2e8f0;
        --slate-100: #f1f5f9;
        --white:       #ffffff;
        --accent:      #dc2626;
        --accent-dark: #991b1b;
        --accent-light:#fff1f2;
        --accent-ring: rgba(220,38,38,0.12);
        --success:     #10b981;
        --danger:      #ef4444;
    }

    .em-form-page {
        font-family: 'Montserrat', sans-serif;
        background: var(--slate-100);
        min-height: 100vh;
        padding: 2rem 1rem 3rem;
    }

    /* ── Hero (minimalista) ── */
    .form-hero {
        background: var(--slate-900);
        border-radius: 16px;
        padding: 1.75rem 2.5rem;
        margin-bottom: 1.75rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1.25rem;
        flex-wrap: wrap;
        position: relative;
        overflow: hidden;
    }
    .form-hero::after {
        content: '';
        position: absolute; left: 0; top: 0; bottom: 0;
        width: 4px;
        background: var(--accent);
        border-radius: 16px 0 0 16px;
    }
    .hero-eyebrow {
        font-size: 0.68rem; font-weight: 700;
        letter-spacing: 0.1em; text-transform: uppercase;
        color: var(--slate-400); margin-bottom: 0.3rem;
    }
    .hero-title {
        font-family: 'Montserrat', sans-serif;
        font-size: 1.4rem; font-weight: 800;
        color: var(--white); margin: 0 0 0.25rem;
        letter-spacing: -0.02em; line-height: 1.2;
    }
    .hero-subtitle { font-size: 0.8rem; color: var(--slate-400); }
    .hero-logo {
        width: 56px; height: 56px; border-radius: 10px;
        object-fit: contain; background: rgba(255,255,255,0.06);
        padding: 6px; flex-shrink: 0;
    }
    .btn-hero-back {
        display: inline-flex; align-items: center; gap: 0.4rem;
        font-family: 'Montserrat', sans-serif; font-weight: 600;
        font-size: 0.78rem; padding: 0.4rem 0.9rem;
        border-radius: 8px; text-decoration: none;
        background: rgba(255,255,255,0.08); color: var(--slate-400);
        border: 1px solid rgba(255,255,255,0.1);
        margin-top: 0.65rem; transition: color 0.2s, background 0.2s;
    }
    .btn-hero-back:hover { color: var(--white); background: rgba(255,255,255,0.13); }

    /* ── Steps bar ── */
    .steps-bar {
        background: var(--white);
        border-radius: 16px 16px 0 0;
        padding: 1.25rem 2rem;
        border-bottom: 1px solid var(--slate-200);
        display: flex; align-items: center; justify-content: space-between;
        position: relative; overflow: hidden;
    }
    .steps-bar::before {
        content: '';
        position: absolute;
        top: 50%; left: 2rem; right: 2rem;
        height: 2px; background: var(--slate-200);
        transform: translateY(-50%); z-index: 0;
    }
    .step-item {
        display: flex; flex-direction: column; align-items: center;
        position: relative; z-index: 1; gap: 0.35rem; flex: 1;
    }
    .step-circle {
        width: 36px; height: 36px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-family: 'Montserrat', sans-serif; font-weight: 800; font-size: 0.82rem;
        border: 2.5px solid var(--slate-200);
        background: var(--white); color: var(--slate-400);
        transition: all 0.3s;
    }
    .step-label-text {
        font-size: 0.65rem; font-weight: 600;
        text-transform: uppercase; letter-spacing: 0.05em;
        color: var(--slate-400); text-align: center; transition: color 0.3s;
    }
    .step-item.active .step-circle {
        background: var(--accent); border-color: var(--accent); color: var(--white);
        box-shadow: 0 0 0 4px var(--accent-ring);
    }
    .step-item.active .step-label-text { color: var(--accent); }
    .step-item.done .step-circle { background: var(--success); border-color: var(--success); color: var(--white); }
    .step-item.done .step-label-text { color: var(--success); }

    /* ── Form card ── */
    .form-card {
        background: var(--white);
        border-radius: 0 0 16px 16px;
        box-shadow: 0 4px 24px rgba(15,23,42,0.08);
        overflow: hidden; margin-bottom: 1.5rem;
    }
    .step-panel { display: none; }
    .step-panel.active { display: block; }

    .section-header {
        padding: 1.1rem 1.75rem;
        border-bottom: 1px solid var(--slate-200);
        display: flex; align-items: center; gap: 0.65rem;
        background: linear-gradient(to right, var(--accent-light), transparent);
    }
    .section-header h5 {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.95rem; font-weight: 700;
        color: var(--slate-900); margin: 0;
    }
    .section-header i { color: var(--accent); font-size: 1rem; }

    .panel-body { padding: 1.75rem; }
    .panel-footer {
        padding: 1rem 1.75rem;
        background: var(--slate-100);
        border-top: 1px solid var(--slate-200);
        display: flex; justify-content: space-between; align-items: center;
    }

    /* ── Controls ── */
    .form-label {
        font-size: 0.75rem; font-weight: 600;
        text-transform: uppercase; letter-spacing: 0.05em;
        color: var(--slate-600); margin-bottom: 0.4rem;
    }
    .req { color: var(--danger); margin-left: 2px; }

    .form-control, .form-select {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.88rem; font-weight: 400;
        border: 1.5px solid var(--slate-200); border-radius: 10px;
        padding: 0.6rem 0.9rem; color: var(--slate-900); background: var(--white);
        transition: border-color 0.2s, box-shadow 0.2s;
    }
    .form-control:focus, .form-select:focus {
        border-color: var(--accent);
        box-shadow: 0 0 0 3px var(--accent-ring); outline: none;
    }
    .form-control.is-invalid, .form-select.is-invalid { border-color: var(--danger); }
    .invalid-feedback { font-size: 0.72rem; }

    /* ── Auto job number ── */
    .job-number-wrap { position: relative; }
    .job-number-input {
        font-family: 'Montserrat', sans-serif !important;
        font-weight: 700 !important; font-size: 1rem !important;
        color: var(--accent-dark) !important;
        background: var(--accent-light) !important;
        border-color: #fecaca !important;
        letter-spacing: 0.04em;
    }
    .job-number-badge {
        position: absolute; right: 10px; top: 50%;
        transform: translateY(-50%);
        font-size: 0.63rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.06em;
        padding: 0.15rem 0.5rem; border-radius: 99px;
        background: #fecaca; color: var(--accent-dark);
        pointer-events: none;
    }

    /* ── Team checkboxes ── */
    .team-check {
        display: flex; align-items: center; gap: 0.75rem;
        padding: 0.75rem 1rem; border-radius: 10px;
        border: 1.5px solid var(--slate-200); background: var(--slate-100);
        cursor: pointer; transition: border-color 0.2s, background 0.2s;
        margin-bottom: 0.5rem;
    }
    .team-check:has(input:checked) { border-color: var(--accent); background: var(--accent-light); }
    .team-check input[type="checkbox"] {
        width: 18px; height: 18px; border-radius: 5px;
        accent-color: var(--accent); flex-shrink: 0; cursor: pointer;
    }
    .team-check-name { font-weight: 600; font-size: 0.88rem; color: var(--slate-900); }
    .team-check-role {
        font-size: 0.68rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.06em; color: var(--slate-400);
    }

    /* ── Terms ── */
    .terms-item {
        display: flex; align-items: flex-start; gap: 0.9rem;
        padding: 1rem 1.25rem; border-radius: 12px;
        border: 1.5px solid var(--slate-200); background: var(--slate-100);
        margin-bottom: 0.75rem; cursor: pointer; transition: border-color 0.2s;
    }
    .terms-item:has(input:checked) { border-color: var(--success); background: #ecfdf5; }
    .terms-item input[type="checkbox"] {
        width: 18px; height: 18px; flex-shrink: 0;
        margin-top: 2px; accent-color: var(--success); cursor: pointer;
    }
    .terms-title { font-weight: 600; font-size: 0.88rem; color: var(--slate-900); }
    .terms-desc  { font-size: 0.78rem; color: var(--slate-500); margin-top: 0.2rem; line-height: 1.5; }

    /* ── File upload ── */
    .file-upload-zone {
        border: 2px dashed var(--slate-300); border-radius: 12px;
        padding: 1.25rem; background: var(--slate-100);
        transition: border-color 0.2s, background 0.2s;
    }
    .file-upload-zone:hover { border-color: var(--accent); background: var(--accent-light); }
    .file-zone-label {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.8rem; font-weight: 700;
        color: var(--slate-800); margin-bottom: 0.15rem; display: block;
    }
    .file-zone-hint { font-size: 0.72rem; color: var(--slate-400); margin-bottom: 0.65rem; }
    .file-upload-zone .form-control { border: none; background: transparent; padding: 0; font-size: 0.85rem; }
    .file-upload-zone .form-control:focus { box-shadow: none; }

    .file-preview-container { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.65rem; }
    .file-preview-item {
        display: inline-flex; align-items: center; gap: 0.4rem;
        background: var(--white); border: 1px solid var(--slate-200);
        border-radius: 8px; padding: 0.3rem 0.65rem;
        font-size: 0.75rem; font-weight: 500; color: var(--slate-700);
    }
    .file-preview-item button {
        background: none; border: none; color: var(--danger);
        cursor: pointer; font-size: 1rem; line-height: 1; padding: 0; margin-left: 2px;
    }

    /* ── Nav buttons ── */
    .btn-nav {
        display: inline-flex; align-items: center; gap: 0.4rem;
        font-family: 'Montserrat', sans-serif; font-weight: 600;
        font-size: 0.85rem; padding: 0.55rem 1.25rem;
        border-radius: 10px; border: none; cursor: pointer;
        transition: filter 0.2s, transform 0.15s;
    }
    .btn-nav:hover { filter: brightness(1.08); transform: translateY(-1px); }
    .btn-nav:disabled { opacity: 0.4; pointer-events: none; }
    .btn-prev { background: var(--slate-200); color: var(--slate-700); }
    .btn-next { background: var(--accent); color: var(--white); box-shadow: 0 3px 10px rgba(220,38,38,0.25); }
    .btn-submit-em {
        display: inline-flex; align-items: center; gap: 0.5rem;
        font-family: 'Montserrat', sans-serif; font-weight: 700;
        font-size: 0.92rem; padding: 0.7rem 2rem;
        border-radius: 12px; border: none;
        background: var(--accent); color: var(--white);
        box-shadow: 0 4px 16px rgba(220,38,38,0.25);
        cursor: pointer; transition: filter 0.2s, transform 0.15s;
    }
    .btn-submit-em:hover { filter: brightness(1.08); transform: translateY(-2px); }

    /* ── Alert ── */
    .alert-ok {
        background: #ecfdf5; border: 1.5px solid #6ee7b7;
        border-radius: 12px; padding: 1rem 1.25rem;
        display: flex; align-items: center; gap: 0.75rem;
        font-size: 0.88rem; color: #065f46; margin-bottom: 1.5rem;
    }

    /* ── Sub-heading ── */
    .sub-heading {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.72rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.07em;
        color: var(--slate-400); margin: 1.25rem 0 0.75rem;
        padding-bottom: 0.4rem;
        border-bottom: 1px dashed var(--slate-200);
    }

    /* ── File sections (matching edit form) ── */
    .file-section {
        border: 1px solid var(--slate-200); border-radius: 12px;
        overflow: hidden; margin-bottom: 1rem;
    }
    .file-section-header {
        padding: 0.75rem 1rem; background: var(--slate-100);
        border-bottom: 1px solid var(--slate-200);
        display: flex; align-items: center; gap: 0.5rem;
        font-size: 0.78rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.05em; color: var(--slate-600);
    }
    .file-section-header i { color: var(--accent); }
    .file-section-body { padding: 1rem; }
    .new-file-entry {
        display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.4rem;
    }
    .new-file-entry input[type="file"] {
        flex: 1; font-size: 0.82rem; cursor: pointer;
        font-family: 'Montserrat', sans-serif;
        border: 1.5px solid var(--slate-200); border-radius: 8px;
        padding: 0.4rem 0.7rem; background: var(--white);
    }
    .btn-add-file {
        display: inline-flex; align-items: center; gap: 0.3rem;
        font-size: 0.75rem; font-weight: 600;
        padding: 0.3rem 0.75rem; border-radius: 7px;
        background: var(--slate-200); color: var(--slate-700);
        border: none; cursor: pointer; margin-top: 0.5rem;
        transition: background 0.2s;
    }
    .btn-add-file:hover { background: var(--slate-300); }
    .btn-remove-file {
        background: none; border: none; color: var(--danger);
        cursor: pointer; font-size: 1rem; padding: 0; flex-shrink: 0; line-height: 1;
    }

    @media (max-width: 576px) {
        .form-hero  { padding: 1.25rem 1.5rem; }
        .hero-title { font-size: 1.2rem; }
        .steps-bar  { padding: 1rem; }
        .step-label-text { display: none; }
        .panel-body { padding: 1.25rem; }
        .panel-footer { padding: 1rem 1.25rem; }
    }
</style>

<div class="em-form-page">
    <div class="container-xl px-0" style="max-width:900px;">

        {{-- Hero --}}
        <div class="form-hero">
            <div>
                <div class="hero-eyebrow"><i class="bi bi-exclamation-octagon me-1"></i> Contracting Alliance Inc.</div>
                <h1 class="hero-title">Emergency Request Form</h1>
                <div class="hero-subtitle">Complete all sections to submit your emergency request</div>
                <a href="{{ route('calendar.view') }}" class="btn-hero-back">
                    <i class="bi bi-arrow-left"></i> Back to Calendar
                </a>
            </div>
            <img src="https://www.jotform.com/uploads/fredysanchezc1980/form_files/IMG_7040.663336b07e6656.75204432.jpeg"
                 alt="Contracting Alliance" class="hero-logo">
        </div>

        {{-- Alert --}}
        @if(session('success'))
            <div class="alert-ok">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif

        {{-- Steps bar --}}
        <div class="steps-bar" id="stepsBar">
            <div class="step-item active" data-step="1">
                <div class="step-circle">1</div>
                <div class="step-label-text">Job Info</div>
            </div>
            <div class="step-item" data-step="2">
                <div class="step-circle">2</div>
                <div class="step-label-text">Address</div>
            </div>
            <div class="step-item" data-step="3">
                <div class="step-circle">3</div>
                <div class="step-label-text">Team</div>
            </div>
            <div class="step-item" data-step="4">
                <div class="step-circle">4</div>
                <div class="step-label-text">Terms</div>
            </div>
            <div class="step-item" data-step="5">
                <div class="step-circle">5</div>
                <div class="step-label-text">Documents</div>
            </div>
        </div>

        <div class="form-card">
            <form action="{{ route('emergency.store') }}" method="POST" enctype="multipart/form-data"
                  id="emForm" novalidate>
                @csrf

                {{-- STEP 1 · Job Information --}}
                <div class="step-panel active" data-step="1">
                    <div class="section-header">
                        <i class="bi bi-file-earmark-text-fill"></i>
                        <h5>Job Information</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Job Number</label>
                                <div class="job-number-wrap">
                                    <input type="text" class="form-control job-number-input"
                                           name="job_number_name" value="{{ $nextEmNumber }}" readonly>
                                    <span class="job-number-badge">Auto</span>
                                </div>
                                <small style="font-size:.7rem;color:var(--slate-400);">Per company sequence</small>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" for="date_submitted">Date Submitted <span class="req">*</span></label>
                                <input type="date" class="form-control" id="date_submitted" name="date_submitted" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" for="type_of_supplement">Type of Emergency <span class="req">*</span></label>
                                <select class="form-select" id="type_of_supplement" name="type_of_supplement" required>
                                    <option value="" disabled selected>Select type...</option>
                                    <option value="New roof installed by a Contracting Alliance sub is leaking (warranty)">New roof installed by a Contracting Alliance sub is leaking (warranty)</option>
                                    <option value="New job, please identify and Stop Leak (minimum $750 charge)">New job, please identify and Stop Leak (minimum $750 charge)</option>
                                    <option value="Emergency Hurricane Tarping Labor and Materials">Emergency Hurricane Tarping Labor and Materials</option>
                                    <option value="Emergency Hurricane Tarping Labor Only">Emergency Hurricane Tarping Labor Only</option>
                                </select>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="company_name">Company Name</label>
                                <input type="text" class="form-control" id="company_name"
                                       name="company_name" value="{{ $user->company_name ?? '' }}" readonly
                                       style="background:var(--slate-100);color:var(--slate-500);">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="company_contact_email">Contact Email <span class="req">*</span></label>
                                <input type="email" class="form-control" id="company_contact_email"
                                       name="company_contact_email" required>
                                <div class="invalid-feedback">Please enter a valid email.</div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev" disabled><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 2 · Address --}}
                <div class="step-panel" data-step="2">
                    <div class="section-header">
                        <i class="bi bi-geo-alt-fill"></i>
                        <h5>Job Address</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label" for="job_address">Street Address <span class="req">*</span></label>
                                <input type="text" class="form-control" id="job_address" name="job_address" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" for="job_address_line2">Address Line 2</label>
                                <input type="text" class="form-control" id="job_address_line2" name="job_address_line2">
                            </div>
                            <div class="col-md-5">
                                <label class="form-label" for="job_city">City <span class="req">*</span></label>
                                <input type="text" class="form-control" id="job_city" name="job_city" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" for="job_state">State <span class="req">*</span></label>
                                <select class="form-select" id="job_state" name="job_state" required>
                                    <option value="" disabled selected>Select...</option>
                                    @foreach(['AL'=>'Alabama','AK'=>'Alaska','AZ'=>'Arizona','AR'=>'Arkansas','CA'=>'California','CO'=>'Colorado','CT'=>'Connecticut','DE'=>'Delaware','DC'=>'District of Columbia','FL'=>'Florida','GA'=>'Georgia','HI'=>'Hawaii','ID'=>'Idaho','IL'=>'Illinois','IN'=>'Indiana','IA'=>'Iowa','KS'=>'Kansas','KY'=>'Kentucky','LA'=>'Louisiana','ME'=>'Maine','MD'=>'Maryland','MA'=>'Massachusetts','MI'=>'Michigan','MN'=>'Minnesota','MS'=>'Mississippi','MO'=>'Missouri','MT'=>'Montana','NE'=>'Nebraska','NV'=>'Nevada','NH'=>'New Hampshire','NJ'=>'New Jersey','NM'=>'New Mexico','NY'=>'New York','NC'=>'North Carolina','ND'=>'North Dakota','OH'=>'Ohio','OK'=>'Oklahoma','OR'=>'Oregon','PA'=>'Pennsylvania','RI'=>'Rhode Island','SC'=>'South Carolina','SD'=>'South Dakota','TN'=>'Tennessee','TX'=>'Texas','UT'=>'Utah','VT'=>'Vermont','VA'=>'Virginia','WA'=>'Washington','WV'=>'West Virginia','WI'=>'Wisconsin','WY'=>'Wyoming'] as $abbr => $name)
                                        <option value="{{ $abbr }}">{{ $abbr }} – {{ $name }}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label" for="job_zip_code">ZIP Code <span class="req">*</span></label>
                                <input type="text" class="form-control" id="job_zip_code" name="job_zip_code" maxlength="10" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 3 · Team Members --}}
                <div class="step-panel" data-step="3">
                    <div class="section-header">
                        <i class="bi bi-people-fill"></i>
                        <h5>Assign Team Members</h5>
                    </div>
                    <div class="panel-body">
                        @php
                            $teamMembers = \App\Models\Team::whereIn('role', ['manager', 'project_manager', 'crew'])
                                ->where('is_active', true)->get();
                            $grouped = $teamMembers->groupBy('role');
                        @endphp
                        @if($teamMembers->isEmpty())
                            <p style="font-size:0.85rem;color:var(--slate-400);font-style:italic;">No active team members available.</p>
                        @else
                            @foreach($grouped as $role => $members)
                                <p style="font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--slate-400);margin:0.75rem 0 0.4rem;">
                                    {{ ucfirst(str_replace('_', ' ', $role)) }}
                                </p>
                                <div class="row g-0">
                                    @foreach($members as $member)
                                        <div class="col-md-6 pe-md-2">
                                            <label class="team-check" for="em_member_{{ $member->id }}">
                                                <input type="checkbox" name="assigned_team_members[]"
                                                       value="{{ $member->id }}" id="em_member_{{ $member->id }}">
                                                <div>
                                                    <div class="team-check-name">{{ $member->name }}</div>
                                                    <div class="team-check-role">{{ ucfirst(str_replace('_', ' ', $member->role)) }}</div>
                                                </div>
                                            </label>
                                        </div>
                                    @endforeach
                                </div>
                            @endforeach
                        @endif
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 4 · Terms & Conditions --}}
                <div class="step-panel" data-step="4">
                    <div class="section-header">
                        <i class="bi bi-file-earmark-check-fill"></i>
                        <h5>Terms & Conditions</h5>
                    </div>
                    <div class="panel-body">
                        <label class="terms-item" for="terms_conditions">
                            <input type="checkbox" id="terms_conditions" name="terms_conditions" required>
                            <div>
                                <div class="terms-title">Supplement Submission Responsibility</div>
                                <div class="terms-desc">I understand it is my company's responsibility to submit the supplement. Contracting Alliance will create the document on your behalf.</div>
                            </div>
                        </label>
                        <label class="terms-item" for="requirements">
                            <input type="checkbox" id="requirements" name="requirements" required>
                            <div>
                                <div class="terms-title">Supplement Processing</div>
                                <div class="terms-desc">I understand that the speed and accuracy of the supplement is based on the information provided, including pictures and/or contracts.</div>
                            </div>
                        </label>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 5 · Documents --}}
                <div class="step-panel" data-step="5">
                    <div class="section-header">
                        <i class="bi bi-paperclip"></i>
                        <h5>Required Documents</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="file-upload-zone">
                                    <span class="file-zone-label"><i class="bi bi-map me-1"></i> Aerial Measurement <span style="color:var(--danger)">*</span></span>
                                    <span class="file-zone-hint">PDF, JPG, PNG · Max 5MB each</span>
                                    <input type="file" class="form-control" name="aerial_measurement[]" multiple
                                           accept=".pdf,.jpg,.jpeg,.png" required
                                           onchange="previewFiles(event,'aerialPreview')">
                                    <div id="aerialPreview"></div>
                                    <div class="invalid-feedback">Please upload at least one file.</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="file-upload-zone">
                                    <span class="file-zone-label"><i class="bi bi-file-earmark-richtext me-1"></i> Contract Upload <span style="color:var(--danger)">*</span></span>
                                    <span class="file-zone-hint">PDF, JPG, PNG · Max 5MB each</span>
                                    <input type="file" class="form-control" name="contract_upload[]" multiple
                                           accept=".pdf,.jpg,.jpeg,.png" required
                                           onchange="previewFiles(event,'contractPreview')">
                                    <div id="contractPreview"></div>
                                    <div class="invalid-feedback">Please upload at least one file.</div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="file-upload-zone">
                                    <span class="file-zone-label"><i class="bi bi-images me-1"></i> Additional Pictures <span style="font-weight:400;color:var(--slate-400);font-size:0.72rem;">(Optional)</span></span>
                                    <span class="file-zone-hint">PDF, JPG, PNG · Max 5MB each</span>
                                    <input type="file" class="form-control" name="file_picture_upload[]" multiple
                                           accept=".pdf,.jpg,.jpeg,.png"
                                           onchange="previewFiles(event,'picturePreview')">
                                    <div id="picturePreview"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="submit" class="btn-submit-em">
                            <i class="bi bi-send-check"></i> Submit Emergency Request
                        </button>
                    </div>
                </div>

            </form>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    let current = 1;
    const TOTAL = 5;

    document.getElementById('date_submitted').value = new Date().toISOString().split('T')[0];

    function showStep(n) {
        document.querySelectorAll('.step-panel').forEach(p => p.classList.remove('active'));
        document.querySelector(`.step-panel[data-step="${n}"]`).classList.add('active');
        document.querySelectorAll('.step-item').forEach(s => {
            const sn = parseInt(s.dataset.step);
            const circle = s.querySelector('.step-circle');
            s.classList.remove('active', 'done');
            if (sn < n) {
                s.classList.add('done');
                circle.innerHTML = '<i class="bi bi-check-lg"></i>';
            } else if (sn === n) {
                s.classList.add('active');
                circle.textContent = sn;
            } else {
                circle.textContent = sn;
            }
        });
        document.getElementById('stepsBar').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function validateStep() {
        const panel = document.querySelector(`.step-panel[data-step="${current}"]`);
        const required = panel.querySelectorAll('[required]');
        let valid = true;
        required.forEach(el => {
            if (!el.value.trim()) {
                el.classList.add('is-invalid');
                if (valid) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); valid = false; }
            } else {
                el.classList.remove('is-invalid');
            }
        });
        return valid;
    }

    document.querySelectorAll('.btn-next').forEach(btn => {
        btn.addEventListener('click', () => {
            if (!validateStep()) return;
            current++; showStep(current);
        });
    });

    document.querySelectorAll('.btn-prev').forEach(btn => {
        btn.addEventListener('click', () => { current--; showStep(current); });
    });

    document.querySelectorAll('.form-control, .form-select').forEach(el => {
        el.addEventListener('input', () => el.classList.remove('is-invalid'));
    });
});

// ── File preview ──────────────────────────────────────────────
const fileMap = { aerial_measurement: [], contract_upload: [], file_picture_upload: [] };

function previewFiles(event, previewId) {
    const key = event.target.name.replace('[]', '');
    fileMap[key] = fileMap[key].concat(Array.from(event.target.files));
    renderPreview(key, previewId, event.target);
}

function removeFile(e, index, key, previewId) {
    e.preventDefault(); e.stopPropagation();
    fileMap[key].splice(index, 1);
    renderPreview(key, previewId);
}

// ── Add more file inputs ─────────────────────────────────────
document.querySelectorAll('.btn-add-file').forEach(btn => {
    btn.addEventListener('click', function () {
        const field = this.dataset.field;
        const container = document.getElementById(field + '-entries');
        const entry = document.createElement('div');
        entry.className = 'new-file-entry';
        entry.innerHTML = `<input type="file" name="${field}[]" accept=".pdf,.jpg,.jpeg,.png">
            <button type="button" class="btn-remove-file">&times;</button>`;
        container.appendChild(entry);
        entry.querySelector('.btn-remove-file').addEventListener('click', () => entry.remove());
    });
});
</script>

@endsection
@extends('layouts.app')

@section('content')

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    :root {
        --slate-900: #0f172a;
        --slate-800: #1e293b;
        --slate-700: #334155;
        --slate-600: #475569;
        --slate-400: #94a3b8;
        --slate-300: #cbd5e1;
        --slate-200: #e2e8f0;
        --slate-100: #f1f5f9;
        --white:       #ffffff;
        --accent:      #3b82f6;
        --accent-dark: #1d4ed8;
        --success:     #10b981;
        --danger:      #ef4444;
        --warning:     #f59e0b;
    }

    .job-form-page {
        font-family: 'Montserrat', sans-serif;
        background: var(--slate-100);
        min-height: 100vh;
        padding: 2rem 1rem 3rem;
    }

    /* ── Hero (minimalista) ── */
    .form-hero {
        background: var(--slate-900);
        border-radius: 16px;
        padding: 1.75rem 2.5rem;
        margin-bottom: 1.75rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1.25rem;
        flex-wrap: wrap;
        position: relative;
        overflow: hidden;
    }
    .form-hero::after {
        content: '';
        position: absolute; left: 0; top: 0; bottom: 0;
        width: 4px;
        background: var(--accent);
        border-radius: 16px 0 0 16px;
    }
    .hero-eyebrow {
        font-size: 0.68rem; font-weight: 700;
        letter-spacing: 0.1em; text-transform: uppercase;
        color: var(--slate-400); margin-bottom: 0.3rem;
    }
    .hero-title {
        font-family: 'Montserrat', sans-serif;
        font-size: 1.4rem; font-weight: 800;
        color: var(--white); margin: 0 0 0.25rem;
        letter-spacing: -0.02em; line-height: 1.2;
    }
    .hero-subtitle { font-size: 0.8rem; color: var(--slate-400); }
    .hero-logo {
        width: 56px; height: 56px; border-radius: 10px;
        object-fit: contain; background: rgba(255,255,255,0.06);
        padding: 6px; flex-shrink: 0;
    }
    .btn-hero-back {
        display: inline-flex; align-items: center; gap: 0.4rem;
        font-family: 'Montserrat', sans-serif; font-weight: 600;
        font-size: 0.78rem; padding: 0.4rem 0.9rem;
        border-radius: 8px; text-decoration: none;
        background: rgba(255,255,255,0.08); color: var(--slate-400);
        border: 1px solid rgba(255,255,255,0.1); margin-top: 0.65rem;
        transition: color 0.2s, background 0.2s;
    }
    .btn-hero-back:hover { color: var(--white); background: rgba(255,255,255,0.13); }

    /* ── Progress Steps ── */
    .steps-bar {
        background: var(--white);
        border-radius: 16px 16px 0 0;
        padding: 1.5rem 2rem;
        border-bottom: 1px solid var(--slate-200);
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: relative;
        overflow: hidden;
    }
    .steps-bar::before {
        content: '';
        position: absolute;
        top: 50%; left: 2rem; right: 2rem;
        height: 2px;
        background: var(--slate-200);
        transform: translateY(-50%);
        z-index: 0;
    }
    .step-item {
        display: flex; flex-direction: column; align-items: center;
        position: relative; z-index: 1; gap: 0.4rem;
        flex: 1;
    }
    .step-circle {
        width: 38px; height: 38px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-family: 'Montserrat', sans-serif; font-weight: 800; font-size: 0.85rem;
        border: 2.5px solid var(--slate-200);
        background: var(--white);
        color: var(--slate-400);
        transition: all 0.3s;
    }
    .step-label-text {
        font-size: 0.68rem; font-weight: 600;
        text-transform: uppercase; letter-spacing: 0.05em;
        color: var(--slate-400); text-align: center;
        transition: color 0.3s;
    }
    .step-item.active .step-circle {
        background: var(--accent); border-color: var(--accent); color: var(--white);
        box-shadow: 0 0 0 4px rgba(59,130,246,0.15);
    }
    .step-item.active .step-label-text { color: var(--accent); }
    .step-item.done .step-circle {
        background: var(--success); border-color: var(--success); color: var(--white);
    }
    .step-item.done .step-label-text { color: var(--success); }

    /* ── Form Card ── */
    .form-card {
        background: var(--white);
        border-radius: 0 0 16px 16px;
        box-shadow: 0 4px 24px rgba(15,23,42,0.08);
        overflow: hidden;
        margin-bottom: 1.5rem;
    }
    .step-panel { display: none; }
    .step-panel.active { display: block; }

    .section-header {
        padding: 1.1rem 1.75rem;
        border-bottom: 1px solid var(--slate-200);
        display: flex; align-items: center; gap: 0.65rem;
        background: linear-gradient(to right, #eff6ff, transparent);
    }
    .section-header h5 {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.95rem; font-weight: 700;
        color: var(--slate-900); margin: 0;
    }
    .section-header i { color: var(--accent); font-size: 1rem; }

    .panel-body { padding: 1.75rem; }

    .panel-footer {
        padding: 1rem 1.75rem;
        background: var(--slate-100);
        border-top: 1px solid var(--slate-200);
        display: flex; justify-content: space-between; align-items: center;
    }

    /* ── Form controls ── */
    .form-label {
        font-size: 0.78rem; font-weight: 600;
        text-transform: uppercase; letter-spacing: 0.05em;
        color: var(--slate-600); margin-bottom: 0.4rem;
    }
    .req { color: var(--danger); margin-left: 2px; }

    .form-control, .form-select {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.9rem; font-weight: 400;
        border: 1.5px solid var(--slate-200);
        border-radius: 10px;
        padding: 0.6rem 0.9rem;
        color: var(--slate-900);
        background: var(--white);
        transition: border-color 0.2s, box-shadow 0.2s;
    }
    .form-control:focus, .form-select:focus {
        border-color: var(--accent);
        box-shadow: 0 0 0 3px rgba(59,130,246,0.12);
        outline: none;
    }
    .form-control.is-invalid, .form-select.is-invalid {
        border-color: var(--danger);
        box-shadow: none;
    }
    .input-group-text {
        background: var(--slate-100);
        border: 1.5px solid var(--slate-200);
        border-right: none;
        border-radius: 10px 0 0 10px;
        color: var(--slate-500);
        font-size: 0.9rem;
    }
    .input-group .form-control { border-radius: 0 10px 10px 0; }
    .invalid-feedback { font-size: 0.75rem; }

    /* ── Auto job number ── */
    .job-number-wrap { position: relative; }
    .job-number-input {
        font-family: 'Montserrat', sans-serif !important;
        font-weight: 700 !important;
        font-size: 1rem !important;
        color: var(--accent-dark) !important;
        background: #eff6ff !important;
        border-color: #bfdbfe !important;
        letter-spacing: 0.04em;
    }
    .job-number-badge {
        position: absolute; right: 10px; top: 50%;
        transform: translateY(-50%);
        font-size: 0.65rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.06em;
        padding: 0.15rem 0.5rem; border-radius: 99px;
        background: #dbeafe; color: var(--accent-dark);
        pointer-events: none;
    }

    /* ── Team checkboxes ── */
    .team-check {
        display: flex; align-items: center; gap: 0.75rem;
        padding: 0.75rem 1rem;
        border-radius: 10px;
        border: 1.5px solid var(--slate-200);
        background: var(--slate-100);
        cursor: pointer;
        transition: border-color 0.2s, background 0.2s;
        margin-bottom: 0.5rem;
    }
    .team-check:has(input:checked) {
        border-color: var(--accent); background: #eff6ff;
    }
    .team-check input[type="checkbox"] {
        width: 18px; height: 18px; border-radius: 5px;
        accent-color: var(--accent); flex-shrink: 0; cursor: pointer;
    }
    .team-check-name { font-weight: 600; font-size: 0.88rem; color: var(--slate-900); }
    .team-check-role {
        font-size: 0.7rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.06em;
        color: var(--slate-400);
    }

    /* ── Terms checkboxes ── */
    .terms-item {
        display: flex; align-items: flex-start; gap: 0.9rem;
        padding: 1.1rem 1.25rem;
        border-radius: 12px;
        border: 1.5px solid var(--slate-200);
        background: var(--slate-100);
        margin-bottom: 0.75rem;
        cursor: pointer;
        transition: border-color 0.2s;
    }
    .terms-item:has(input:checked) { border-color: var(--accent); background: #eff6ff; }
    .terms-item input[type="checkbox"] {
        width: 18px; height: 18px; flex-shrink: 0;
        margin-top: 2px; accent-color: var(--accent); cursor: pointer;
    }
    .terms-title { font-weight: 600; font-size: 0.88rem; color: var(--slate-900); }
    .terms-desc  { font-size: 0.8rem; color: var(--slate-500); margin-top: 0.25rem; line-height: 1.5; }

    /* ── File upload zone ── */
    .file-upload-zone {
        border: 2px dashed var(--slate-300);
        border-radius: 12px;
        padding: 1.25rem;
        background: var(--slate-100);
        transition: border-color 0.2s, background 0.2s;
    }
    .file-upload-zone:hover { border-color: var(--accent); background: #eff6ff; }
    .file-zone-label {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.82rem; font-weight: 700;
        color: var(--slate-800); margin-bottom: 0.15rem; display: block;
    }
    .file-zone-hint { font-size: 0.72rem; color: var(--slate-400); margin-bottom: 0.65rem; }
    .file-upload-zone .form-control { border: none; background: transparent; padding: 0; font-size: 0.85rem; }
    .file-upload-zone .form-control:focus { box-shadow: none; }

    .btn-add-file {
        display: inline-flex; align-items: center; gap: 0.3rem;
        font-size: 0.75rem; font-weight: 600;
        padding: 0.3rem 0.75rem; border-radius: 7px;
        background: var(--slate-200); color: var(--slate-700);
        border: none; cursor: pointer; margin-top: 0.5rem;
        transition: background 0.2s;
    }
    .btn-add-file:hover { background: var(--slate-300); }

    .file-entry { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.4rem; }
    .file-entry .form-control { font-size: 0.82rem; }
    .btn-remove-file {
        background: none; border: none; color: var(--danger);
        cursor: pointer; font-size: 1.1rem; padding: 0; flex-shrink: 0;
        line-height: 1;
    }

    /* ── Nav buttons ── */
    .btn-nav {
        display: inline-flex; align-items: center; gap: 0.4rem;
        font-family: 'Montserrat', sans-serif; font-weight: 600;
        font-size: 0.85rem; padding: 0.55rem 1.25rem;
        border-radius: 10px; border: none; cursor: pointer;
        transition: filter 0.2s, transform 0.15s;
    }
    .btn-nav:hover { filter: brightness(1.08); transform: translateY(-1px); }
    .btn-nav:disabled { opacity: 0.4; pointer-events: none; }
    .btn-prev { background: var(--slate-200); color: var(--slate-700); }
    .btn-next { background: var(--accent); color: var(--white); box-shadow: 0 3px 10px rgba(59,130,246,0.3); }
    .btn-submit-job {
        display: inline-flex; align-items: center; gap: 0.5rem;
        font-family: 'Montserrat', sans-serif; font-weight: 700;
        font-size: 0.95rem; padding: 0.7rem 2rem;
        border-radius: 12px; border: none;
        background: linear-gradient(135deg, var(--success), #0f6848);
        color: var(--white);
        box-shadow: 0 4px 16px rgba(16,185,129,0.3);
        cursor: pointer; transition: filter 0.2s, transform 0.15s;
    }
    .btn-submit-job:hover { filter: brightness(1.08); transform: translateY(-2px); }

    /* ── Alert ── */
    .alert-success-custom {
        background: #ecfdf5; border: 1.5px solid #6ee7b7;
        border-radius: 12px; padding: 1rem 1.25rem;
        display: flex; align-items: center; gap: 0.75rem;
        font-size: 0.88rem; color: #065f46; margin-bottom: 1.5rem;
    }

    /* ── Section sub-label ── */
    .sub-heading {
        font-family: 'Montserrat', sans-serif;
        font-size: 0.75rem; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.07em;
        color: var(--slate-400); margin: 1.25rem 0 0.75rem;
        padding-bottom: 0.4rem;
        border-bottom: 1px dashed var(--slate-200);
    }

    @media (max-width: 576px) {
        .form-hero  { padding: 1.5rem 1.25rem; }
        .hero-title { font-size: 1.25rem; }
        .steps-bar  { padding: 1rem; }
        .step-label-text { display: none; }
        .panel-body { padding: 1.25rem; }
        .panel-footer { padding: 1rem 1.25rem; }
    }
</style>

<div class="job-form-page">
    <div class="container-xl px-0" style="max-width:900px;">

        {{-- Hero --}}
        <div class="form-hero">
            <div>
                <div class="hero-eyebrow"><i class="bi bi-briefcase me-1"></i> Contracting Alliance Inc.</div>
                <h1 class="hero-title">Job Request Form</h1>
                <div class="hero-subtitle">Fill out all sections to submit your job request</div>
                <a href="{{ route('calendar.view') }}" class="btn-hero-back">
                    <i class="bi bi-arrow-left"></i> Back to Calendar
                </a>
            </div>
            <img src="https://www.jotform.com/uploads/fredysanchezc1980/form_files/IMG_7040.663336b07e6656.75204432.jpeg"
                 alt="Contracting Alliance" class="hero-logo">
        </div>

        {{-- Success Alert --}}
        @if(session('success'))
            <div class="alert-success-custom">
                <i class="bi bi-check-circle-fill fs-5"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif

        {{-- Steps bar --}}
        <div class="steps-bar" id="stepsBar">
            <div class="step-item active" data-step="1">
                <div class="step-circle" id="sc1">1</div>
                <div class="step-label-text">General</div>
            </div>
            <div class="step-item" data-step="2">
                <div class="step-circle" id="sc2">2</div>
                <div class="step-label-text">Customer</div>
            </div>
            <div class="step-item" data-step="3">
                <div class="step-circle" id="sc3">3</div>
                <div class="step-label-text">Location</div>
            </div>
            <div class="step-item" data-step="4">
                <div class="step-circle" id="sc4">4</div>
                <div class="step-label-text">Materials</div>
            </div>
            <div class="step-item" data-step="5">
                <div class="step-circle" id="sc5">5</div>
                <div class="step-label-text">Inspections</div>
            </div>
            <div class="step-item" data-step="6">
                <div class="step-circle" id="sc6">6</div>
                <div class="step-label-text">Attachments</div>
            </div>
        </div>

        <div class="form-card">
            <form action="{{ route('jobs.store') }}" method="POST" enctype="multipart/form-data"
                  id="jobForm" novalidate>
                @csrf

                {{-- STEP 1 · General Information --}}
                <div class="step-panel active" data-step="1">
                    <div class="section-header">
                        <i class="bi bi-building-fill"></i>
                        <h5>General Information</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Job Number</label>
                                <div class="job-number-wrap">
                                    <input type="text" class="form-control job-number-input"
                                           name="job_number_name" value="{{ $nextJrNumber }}" readonly>
                                    <span class="job-number-badge">Auto</span>
                                </div>
                                <small style="font-size:.72rem;color:var(--slate-400);">Assigned automatically · Per company sequence</small>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" for="install_date_requested">Install Date <span class="req">*</span></label>
                                <input type="date" class="form-control" id="install_date_requested"
                                       name="install_date_requested" min="{{ date('Y-m-d') }}" required>
                                <div class="invalid-feedback">Please select a date.</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" for="company_name">Company Name</label>
                                <input type="text" class="form-control" id="company_name"
                                       name="company_name" value="{{ $user->company_name }}" readonly
                                       style="background:var(--slate-100);color:var(--slate-500);">
                                <input type="hidden" name="company_rep_email" value="{{ $user->email }}">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="company_rep">Company Representative <span class="req">*</span></label>
                                <input type="text" class="form-control" id="company_rep"
                                       name="company_rep" placeholder="Full name" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="company_rep_phone">Representative Phone <span class="req">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                                    <input type="tel" class="form-control" id="company_rep_phone"
                                           name="company_rep_phone" value="{{ $user->phone }}" required>
                                </div>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev" disabled><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 2 · Customer Information --}}
                <div class="step-panel" data-step="2">
                    <div class="section-header">
                        <i class="bi bi-person-fill"></i>
                        <h5>Customer Information</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" for="customer_first_name">First Name <span class="req">*</span></label>
                                <input type="text" class="form-control" id="customer_first_name"
                                       name="customer_first_name" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="customer_last_name">Last Name</label>
                                <input type="text" class="form-control" id="customer_last_name" name="customer_last_name">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="customer_phone_number">Customer Phone <span class="req">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                                    <input type="tel" class="form-control" id="customer_phone_number"
                                           name="customer_phone_number" required>
                                </div>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 3 · Job Location & Team --}}
                <div class="step-panel" data-step="3">
                    <div class="section-header">
                        <i class="bi bi-geo-alt-fill"></i>
                        <h5>Job Location & Team</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label" for="job_address_street_address">Street Address <span class="req">*</span></label>
                                <input type="text" class="form-control" id="job_address_street_address"
                                       name="job_address_street_address" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" for="job_address_street_address_line_2">Line 2</label>
                                <input type="text" class="form-control" id="job_address_street_address_line_2"
                                       name="job_address_street_address_line_2">
                            </div>
                            <div class="col-md-5">
                                <label class="form-label" for="job_address_city">City <span class="req">*</span></label>
                                <input type="text" class="form-control" id="job_address_city"
                                       name="job_address_city" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" for="job_address_state">State <span class="req">*</span></label>
                                <select class="form-select" id="job_address_state" name="job_address_state" required>
                                    <option value="" disabled selected>Select...</option>
                                    @foreach(['AL'=>'Alabama','AK'=>'Alaska','AZ'=>'Arizona','AR'=>'Arkansas','CA'=>'California','CO'=>'Colorado','CT'=>'Connecticut','DE'=>'Delaware','DC'=>'District of Columbia','FL'=>'Florida','GA'=>'Georgia','HI'=>'Hawaii','ID'=>'Idaho','IL'=>'Illinois','IN'=>'Indiana','IA'=>'Iowa','KS'=>'Kansas','KY'=>'Kentucky','LA'=>'Louisiana','ME'=>'Maine','MD'=>'Maryland','MA'=>'Massachusetts','MI'=>'Michigan','MN'=>'Minnesota','MS'=>'Mississippi','MO'=>'Missouri','MT'=>'Montana','NE'=>'Nebraska','NV'=>'Nevada','NH'=>'New Hampshire','NJ'=>'New Jersey','NM'=>'New Mexico','NY'=>'New York','NC'=>'North Carolina','ND'=>'North Dakota','OH'=>'Ohio','OK'=>'Oklahoma','OR'=>'Oregon','PA'=>'Pennsylvania','RI'=>'Rhode Island','SC'=>'South Carolina','SD'=>'South Dakota','TN'=>'Tennessee','TX'=>'Texas','UT'=>'Utah','VT'=>'Vermont','VA'=>'Virginia','WA'=>'Washington','WV'=>'West Virginia','WI'=>'Wisconsin','WY'=>'Wyoming'] as $abbr => $name)
                                        <option value="{{ $abbr }}">{{ $abbr }} – {{ $name }}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label" for="job_address_zip_code">ZIP <span class="req">*</span></label>
                                <input type="text" class="form-control" id="job_address_zip_code"
                                       name="job_address_zip_code" maxlength="10" required>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-12 mt-2">
                                <div class="sub-heading"><i class="bi bi-people me-1"></i> Assign Team Members</div>
                                @php $grouped = $teamMembers->groupBy('role'); @endphp
                                @foreach($grouped as $role => $members)
                                    <p style="font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--slate-400);margin:0.75rem 0 0.4rem;">
                                        {{ ucfirst(str_replace('_', ' ', $role)) }}
                                    </p>
                                    <div class="row g-0">
                                        @foreach($members as $member)
                                            <div class="col-md-6 pe-md-2">
                                                <label class="team-check" for="jm_{{ $member->id }}">
                                                    <input type="checkbox" name="assigned_team_members[]"
                                                           value="{{ $member->id }}" id="jm_{{ $member->id }}">
                                                    <div>
                                                        <div class="team-check-name">{{ $member->name }}</div>
                                                        <div class="team-check-role">{{ ucfirst(str_replace('_',' ',$member->role)) }}</div>
                                                    </div>
                                                </label>
                                            </div>
                                        @endforeach
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 4 · Materials --}}
                <div class="step-panel" data-step="4">
                    <div class="section-header">
                        <i class="bi bi-box-seam-fill"></i>
                        <h5>Materials Details</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" for="material_roof_loaded">Material Roof Loaded <span class="req">*</span></label>
                                <select class="form-select" id="material_roof_loaded" name="material_roof_loaded" required>
                                    <option value="" disabled selected>Select...</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                <div class="invalid-feedback">Required.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="delivery_date">Delivery Date</label>
                                <input type="date" class="form-control" id="delivery_date" name="delivery_date">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Starter Bundles</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="starter_bundles_ordered" min="0">
                                    <span class="input-group-text" style="border-left:none;border-radius:0 10px 10px 0;">bundles</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Hip & Ridge</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="hip_and_ridge_ordered" min="0">
                                    <span class="input-group-text" style="border-left:none;border-radius:0 10px 10px 0;">bundles</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Field Shingle Bundles</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="field_shingle_bundles_ordered" min="0">
                                    <span class="input-group-text" style="border-left:none;border-radius:0 10px 10px 0;">bundles</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Modified Bitumen Cap Rolls</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="modified_bitumen_cap_rolls_ordered" min="0">
                                    <span class="input-group-text" style="border-left:none;border-radius:0 10px 10px 0;">rolls</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 5 · Inspections & Terms --}}
                <div class="step-panel" data-step="5">
                    <div class="section-header">
                        <i class="bi bi-clipboard2-check-fill"></i>
                        <h5>Inspections & Terms</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" for="mid_roof_inspection">Mid Roof Inspection</label>
                                <select class="form-select" id="mid_roof_inspection" name="mid_roof_inspection">
                                    <option value="" disabled selected>Select...</option>
                                    <option>Yes</option><option>No</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="siding_being_replaced">Siding Being Replaced</label>
                                <select class="form-select" id="siding_being_replaced" name="siding_being_replaced">
                                    <option value="" disabled selected>Select...</option>
                                    <option>Yes</option><option>No</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="asphalt_shingle_layers_to_remove">Shingle Layers to Remove</label>
                                <select class="form-select" id="asphalt_shingle_layers_to_remove" name="asphalt_shingle_layers_to_remove">
                                    <option value="" disabled selected>Select...</option>
                                    @for($i=1;$i<=6;$i++) <option>{{ $i }}</option> @endfor
                                </select>
                            </div>
                            @foreach([
                                're_deck'                     => 'Re Deck',
                                'skylights_replace'           => 'Skylights Replace',
                                'gutter_remove'               => 'Gutter Remove',
                                'gutter_detached_and_reset'   => 'Gutter Detached & Reset',
                                'satellite_remove'            => 'Satellite Remove',
                                'satellite_goes_in_the_trash' => 'Satellite Goes in Trash',
                                'open_soffit_ceiling'         => 'Open Soffit Ceiling',
                                'detached_garage_roof'        => 'Detached Garage Roof',
                                'detached_shed_roof'          => 'Detached Shed Roof',
                            ] as $field => $label)
                                <div class="col-md-6">
                                    <label class="form-label" for="{{ $field }}">{{ $label }}</label>
                                    <select class="form-select" id="{{ $field }}" name="{{ $field }}">
                                        <option value="" disabled selected>Select...</option>
                                        <option>Yes</option><option>No</option>
                                    </select>
                                </div>
                            @endforeach
                            <div class="col-12">
                                <label class="form-label" for="special_instructions">Special Instructions</label>
                                <textarea class="form-control" id="special_instructions"
                                          name="special_instructions" rows="3"
                                          placeholder="Any specific notes or expectations..."></textarea>
                            </div>
                            <div class="col-12 mt-1">
                                <div class="sub-heading"><i class="bi bi-file-earmark-check me-1"></i> Required Acknowledgements</div>
                                <label class="terms-item" for="material_verification">
                                    <input type="checkbox" id="material_verification" name="material_verification" value="1">
                                    <div>
                                        <div class="terms-title">Material Verification</div>
                                        <div class="terms-desc">I understand it is my company's responsibility to alert Contracting Alliance the night before construction if materials are not on site.</div>
                                    </div>
                                </label>
                                <label class="terms-item" for="stop_work_request">
                                    <input type="checkbox" id="stop_work_request" name="stop_work_request" value="1">
                                    <div>
                                        <div class="terms-title">Stop Work Request</div>
                                        <div class="terms-desc">Our company is obligated to notify Contracting Alliance by 4:00 PM Central Time the day prior to any scheduled construction if the project is to be put on hold.</div>
                                    </div>
                                </label>
                                <label class="terms-item" for="documentationattachment">
                                    <input type="checkbox" id="documentationattachment" name="documentationattachment" value="1">
                                    <div>
                                        <div class="terms-title">Required Documentation</div>
                                        <div class="terms-desc">Aerial measurement, material order, and photos are required. If not included, this can delay your build.</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="button" class="btn-nav btn-next">Next <i class="bi bi-arrow-right"></i></button>
                    </div>
                </div>

                {{-- STEP 6 · Attachments --}}
                <div class="step-panel" data-step="6">
                    <div class="section-header">
                        <i class="bi bi-paperclip"></i>
                        <h5>Attachments</h5>
                    </div>
                    <div class="panel-body">
                        <div class="row g-3">
                            @foreach([
                                'aerial_measurement' => ['Aerial Measurement',              'bi-map'],
                                'material_order'     => ['Material Order',                  'bi-cart-check'],
                                'file_upload'        => ['Other Files (Permit / SOL / etc)', 'bi-file-earmark'],
                            ] as $field => [$label, $icon])
                                <div class="col-md-6">
                                    <div class="file-upload-zone">
                                        <span class="file-zone-label"><i class="bi {{ $icon }} me-1"></i> {{ $label }}</span>
                                        <span class="file-zone-hint">PDF, JPG, PNG, WEBP · Max 5MB each</span>
                                        <div id="{{ $field }}-entries">
                                            <div class="file-entry">
                                                <input type="file" name="{{ $field }}[]" class="form-control"
                                                       accept=".pdf,.jpg,.jpeg,.png,.webp">
                                            </div>
                                        </div>
                                        <button type="button" class="btn-add-file" data-field="{{ $field }}">
                                            <i class="bi bi-plus"></i> Add file
                                        </button>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="button" class="btn-nav btn-prev"><i class="bi bi-arrow-left"></i> Previous</button>
                        <button type="submit" class="btn-submit-job">
                            <i class="bi bi-check-circle"></i> Submit Job Request
                        </button>
                    </div>
                </div>

            </form>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    let current = 1;

    function showStep(n) {
        document.querySelectorAll('.step-panel').forEach(p => p.classList.remove('active'));
        document.querySelector(`.step-panel[data-step="${n}"]`).classList.add('active');
        document.querySelectorAll('.step-item').forEach(s => {
            const sn = parseInt(s.dataset.step);
            const circle = s.querySelector('.step-circle');
            s.classList.remove('active', 'done');
            if (sn < n) {
                s.classList.add('done');
                circle.innerHTML = '<i class="bi bi-check-lg"></i>';
            } else if (sn === n) {
                s.classList.add('active');
                circle.textContent = sn;
            } else {
                circle.textContent = sn;
            }
        });
        document.getElementById('stepsBar').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function validateCurrentStep() {
        const panel = document.querySelector(`.step-panel[data-step="${current}"]`);
        const required = panel.querySelectorAll('[required]');
        let valid = true;
        required.forEach(el => {
            if (!el.value.trim()) {
                el.classList.add('is-invalid');
                if (valid) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); valid = false; }
            } else {
                el.classList.remove('is-invalid');
            }
        });
        return valid;
    }

    document.querySelectorAll('.btn-next').forEach(btn => {
        btn.addEventListener('click', () => {
            if (!validateCurrentStep()) return;
            current++; showStep(current);
        });
    });

    document.querySelectorAll('.btn-prev').forEach(btn => {
        btn.addEventListener('click', () => { current--; showStep(current); });
    });

    document.querySelectorAll('.btn-add-file').forEach(btn => {
        btn.addEventListener('click', function () {
            const field = this.dataset.field;
            const container = document.getElementById(`${field}-entries`);
            const entry = document.createElement('div');
            entry.className = 'file-entry';
            entry.innerHTML = `<input type="file" name="${field}[]" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.webp">
                <button type="button" class="btn-remove-file">&times;</button>`;
            container.appendChild(entry);
            entry.querySelector('.btn-remove-file').addEventListener('click', () => entry.remove());
        });
    });

    document.querySelectorAll('.form-control, .form-select').forEach(el => {
        el.addEventListener('input', () => el.classList.remove('is-invalid'));
    });
});
</script>

@endsection
@extends('layouts.app')

@section('content')

<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.2/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
:root {
    --bg:#f6f7f9;--surf:#ffffff;--bd:rgba(0,0,0,.07);--bd-md:rgba(0,0,0,.12);
    --tx:#0d0f12;--tx2:#5a6272;--tx3:#9099a8;
    --blue:#2563eb;--blue-bg:#eff4ff;--blue-bd:#bfcffe;
    --green:#16a34a;--green-bg:#f0fdf4;--green-bd:#bbf7d0;
    --amber:#d97706;--amber-bg:#fffbeb;--amber-bd:#fde68a;
    --red:#dc2626;--red-bg:#fef2f2;--red-bd:#fecaca;
    --purple:#7c3aed;--purple-bg:#faf5ff;--purple-bd:#ddd6fe;
    --cyan:#0e7490;--cyan-bg:#ecfeff;--cyan-bd:#a5f3fc;
    --r:8px;--r-lg:12px;--r-xl:16px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--bg);font-family:'Inter',-apple-system,sans-serif;color:var(--tx);font-size:14px;line-height:1.5;}
a{color:inherit;text-decoration:none;}
.cal-page{padding:24px 28px;max-width:1600px;margin:0 auto;}
.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
.topbar-left{display:flex;align-items:center;gap:12px;}
.topbar-title{font-size:18px;font-weight:600;letter-spacing:-.3px;}
.topbar-sub{font-size:12px;color:var(--tx3);margin-top:1px;}
.topbar-actions{display:flex;gap:8px;}
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:var(--r);font-size:13px;font-weight:500;border:1px solid transparent;cursor:pointer;transition:all .15s;font-family:inherit;white-space:nowrap;text-decoration:none;}
.btn-ghost{background:var(--surf);border-color:var(--bd-md);color:var(--tx2);}
.btn-ghost:hover{background:var(--bg);color:var(--tx);}
.btn-primary{background:var(--blue);color:#fff;}
.btn-primary:hover{background:#1d4ed8;color:#fff;}
.btn-danger{background:var(--red);color:#fff;}
.btn-danger:hover{background:#b91c1c;color:#fff;}
.btn-sm{padding:5px 10px;font-size:12px;}
.stats-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:20px;}
.stat{background:var(--surf);border:1px solid var(--bd);border-radius:var(--r-lg);padding:16px 18px;display:flex;align-items:flex-start;gap:12px;position:relative;overflow:hidden;}
.stat-dot{width:8px;height:8px;border-radius:50%;margin-top:5px;flex-shrink:0;}
.stat-dot.blue{background:var(--blue);}.stat-dot.red{background:var(--red);}
.stat-dot.cyan{background:var(--cyan);}.stat-dot.purple{background:var(--purple);}
.stat-dot.gray{background:var(--tx3);}
.stat-num{font-size:26px;font-weight:600;letter-spacing:-.5px;line-height:1;}
.stat-lbl{font-size:11px;color:var(--tx3);margin-top:3px;text-transform:uppercase;letter-spacing:.5px;font-weight:500;}
.stat-bar{position:absolute;bottom:0;left:0;height:2px;width:100%;background:var(--bd);}
.stat-bar-fill{height:100%;border-radius:2px;transition:width .4s ease;}
.stat-bar-fill.blue{background:var(--blue);}.stat-bar-fill.red{background:var(--red);}
.stat-bar-fill.cyan{background:var(--cyan);}.stat-bar-fill.purple{background:var(--purple);}
.stat-bar-fill.gray{background:var(--tx3);}
.cal-search-wrap{display:flex;align-items:center;gap:8px;background:var(--surf);border:1px solid var(--bd);border-radius:var(--r-lg);padding:10px 16px;margin-bottom:12px;box-shadow:0 1px 4px rgba(0,0,0,.05);flex-wrap:wrap;}
.cal-search-ico{font-size:14px;color:var(--tx3);flex-shrink:0;}
.cal-search-input{flex:1;min-width:160px;border:none;outline:none;font-size:13px;font-family:'Inter',sans-serif;color:var(--tx);background:transparent;}
.cal-search-input::placeholder{color:var(--tx3);}
.cal-search-clear{background:none;border:none;cursor:pointer;color:var(--tx3);font-size:13px;padding:2px 4px;display:none;align-items:center;}
.cal-search-clear:hover{color:var(--tx);}
.cal-search-count{font-size:12px;font-weight:600;color:var(--blue);background:var(--blue-bg);border:1px solid var(--blue-bd);border-radius:9999px;padding:2px 10px;white-space:nowrap;flex-shrink:0;display:none;}
.cal-filter-chips{display:flex;gap:6px;align-items:center;flex-wrap:wrap;}
.cal-chip{display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:600;padding:3px 10px;border-radius:99px;border:1.5px solid;cursor:pointer;transition:all .15s;user-select:none;font-family:'Inter',sans-serif;}
.cal-chip.chip-job{color:var(--blue);border-color:var(--blue-bd);background:var(--blue-bg);}
.cal-chip.chip-emerg{color:var(--red);border-color:var(--red-bd);background:var(--red-bg);}
.cal-chip.chip-repair{color:var(--cyan);border-color:var(--cyan-bd);background:var(--cyan-bg);}
.cal-chip.chip-appr{color:var(--purple);border-color:var(--purple-bd);background:var(--purple-bg);}
.cal-chip.off{opacity:.4;filter:grayscale(.8);}
.cal-chip-dot{width:6px;height:6px;border-radius:50%;background:currentColor;}
.search-notice{display:none;align-items:center;gap:8px;background:var(--cyan-bg);border:1px solid var(--cyan-bd);border-radius:var(--r);padding:9px 14px;font-size:12px;font-weight:600;color:var(--cyan);margin-bottom:12px;}
.search-notice.visible{display:flex;}
.search-notice a{margin-left:auto;color:var(--cyan);font-size:11px;font-weight:700;}
.cal-wrap{background:var(--surf);border:1px solid var(--bd);border-radius:var(--r-xl);overflow:hidden;}
.cal-inner{padding:20px 20px 24px;}
.fc{font-family:'Inter',-apple-system,sans-serif !important;}
.fc .fc-header-toolbar{margin-bottom:16px !important;padding:0;align-items:center;}
.fc .fc-toolbar-title{font-size:15px !important;font-weight:600 !important;letter-spacing:-.2px;color:var(--tx) !important;}
.fc .fc-button{background:var(--surf) !important;border:1px solid var(--bd-md) !important;color:var(--tx2) !important;border-radius:var(--r) !important;padding:5px 10px !important;font-size:12px !important;font-weight:500 !important;box-shadow:none !important;font-family:'Inter',sans-serif !important;transition:all .15s !important;}
.fc .fc-button:hover{background:var(--bg) !important;color:var(--tx) !important;}
.fc .fc-button-active,.fc .fc-button-primary:not(:disabled).fc-button-active{background:var(--blue) !important;border-color:var(--blue) !important;color:#fff !important;}
.fc .fc-button-group{gap:4px;}
.fc .fc-daygrid-day-number{font-size:12px;font-weight:500;color:var(--tx2);padding:6px 8px !important;text-decoration:none;}
.fc .fc-day-today .fc-daygrid-day-number{background:var(--blue);color:#fff;border-radius:50%;width:24px;height:24px;display:flex;align-items:center;justify-content:center;margin:4px;padding:0 !important;font-size:11px;}
.fc .fc-col-header-cell-cushion{font-size:11px;font-weight:600;color:var(--tx3);text-transform:uppercase;letter-spacing:.6px;text-decoration:none;padding:8px 4px;}
.fc .fc-event{border:none !important;border-radius:5px !important;padding:3px 7px 4px !important;font-size:11.5px !important;font-weight:500 !important;cursor:pointer;margin-bottom:2px;box-shadow:none !important;transition:opacity .1s,filter .1s;}
.fc .fc-event:hover{opacity:.85;filter:brightness(1.06);}
.fc th,.fc td{border-color:var(--bd) !important;}
.fc .fc-scrollgrid{border-color:var(--bd) !important;}
.fc .fc-daygrid-day.fc-day-today{background:var(--blue-bg) !important;}
.fc .fc-daygrid-day{min-height:80px;}
.fc .fc-more-link{font-size:11px;color:var(--blue);font-weight:500;padding:1px 6px;}
.fc .fc-list-day-cushion{background:var(--bg) !important;font-size:12px !important;font-weight:600 !important;}
.fc .fc-list-event-title a{text-decoration:none !important;font-weight:600 !important;color:var(--tx) !important;}
.fc .fc-popover{border-radius:var(--r-xl) !important;border:1px solid var(--bd-md) !important;box-shadow:0 8px 32px rgba(0,0,0,.18) !important;overflow:hidden !important;font-family:'Inter',sans-serif !important;min-width:220px !important;}
.fc .fc-popover-header{background:#0f1117 !important;color:#fff !important;padding:10px 14px !important;font-size:12px !important;font-weight:600 !important;border-bottom:none !important;}
.fc .fc-popover-close{color:rgba(255,255,255,.5) !important;opacity:1 !important;}
.fc .fc-popover-close:hover{color:#fff !important;}
.fc .fc-popover-body{background:var(--surf) !important;padding:8px !important;display:flex !important;flex-direction:column !important;gap:4px !important;}
.fc .fc-popover-body .fc-event{border-radius:8px !important;padding:5px 9px 6px !important;margin:0 !important;}

/* DRAWER */
/* sin backdrop — el calendario sigue navegable */
.drawer{position:fixed;top:0;right:0;bottom:0;z-index:1050;width:440px;max-width:100vw;background:var(--surf);box-shadow:-12px 0 48px rgba(0,0,0,.22);display:flex;flex-direction:column;transform:translateX(100%);transition:transform .3s cubic-bezier(.4,0,.2,1);border-left:1px solid var(--bd-md);}
.drawer.open{transform:translateX(0);}
.drawer-head{display:flex;align-items:center;justify-content:space-between;padding:18px 22px 16px;border-bottom:1px solid var(--bd);background:#0f1117;flex-shrink:0;}
.drawer-head-date{font-size:15px;font-weight:700;color:#fff;letter-spacing:-.3px;}
.drawer-head-day{font-size:11px;color:rgba(255,255,255,.45);font-weight:500;margin-top:2px;}
.drawer-close{width:32px;height:32px;border-radius:9px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s;flex-shrink:0;}
.drawer-close:hover{background:rgba(255,255,255,.16);color:#fff;}
.drawer-tabs{display:flex;background:var(--bg);border-bottom:1px solid var(--bd);flex-shrink:0;}
.drawer-tab{flex:1;padding:11px 12px 10px;background:none;border:none;font-size:12px;font-weight:500;color:var(--tx3);cursor:pointer;border-bottom:2.5px solid transparent;transition:color .15s,border-color .15s,background .15s;display:flex;align-items:center;justify-content:center;gap:6px;font-family:'Inter',sans-serif;}
.drawer-tab:hover{color:var(--tx);background:rgba(0,0,0,.03);}
.drawer-tab.on{color:var(--blue);border-bottom-color:var(--blue);background:var(--surf);font-weight:600;}
.drawer-tab.tab-repair.on{color:var(--cyan);border-bottom-color:var(--cyan);}
.drawer-tab i{font-size:11px;}
.drawer-body{flex:1;overflow-y:auto;}
.drawer-panel{display:none;}
.drawer-panel.on{display:block;animation:dpIn .18s ease;}
@keyframes dpIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
.drawer-events{padding:16px;display:flex;flex-direction:column;gap:10px;}
.ev-card{border-radius:var(--r-lg);overflow:hidden;border:1px solid var(--bd);background:var(--surf);transition:box-shadow .15s,border-color .15s;}
.ev-card:hover{box-shadow:0 3px 14px rgba(15,23,42,.09);border-color:var(--bd-md);}
.ev-card-top{display:flex;align-items:stretch;}
.ev-card-bar{width:4px;flex-shrink:0;}
.ev-card-body{padding:12px 14px;flex:1;min-width:0;}
.ev-card-title{font-size:13px;font-weight:700;color:var(--tx);margin-bottom:5px;line-height:1.3;}
.ev-card-meta{display:flex;flex-wrap:wrap;gap:8px;font-size:11.5px;color:var(--tx3);}
.ev-card-meta-item{display:flex;align-items:center;gap:4px;}
.ev-card-meta-item i{font-size:10px;}
.ev-card-footer{display:flex;align-items:center;justify-content:space-between;padding:8px 14px;border-top:1px solid var(--bd);background:var(--bg);}
.ev-status-pill{display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;padding:3px 9px;border-radius:99px;color:#fff;}
.ev-type-pill{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;padding:2px 8px;border-radius:99px;border:1px solid;flex-shrink:0;}
.ev-type-job{color:var(--blue);background:var(--blue-bg);border-color:var(--blue-bd);}
.ev-type-emerg{color:var(--red);background:var(--red-bg);border-color:var(--red-bd);}
.ev-type-appr{color:var(--purple);background:var(--purple-bg);border-color:var(--purple-bd);}
.ev-type-repair{color:var(--cyan);background:var(--cyan-bg);border-color:var(--cyan-bd);}
.btn-open{display:inline-flex;align-items:center;gap:5px;font-size:11.5px;font-weight:600;padding:5px 12px;border-radius:var(--r);background:var(--tx);color:#fff;text-decoration:none;transition:opacity .15s;}
.btn-open:hover{opacity:.82;color:#fff;}
.empty-day{text-align:center;padding:48px 20px;color:var(--tx3);}
.empty-day i{font-size:26px;display:block;margin-bottom:10px;opacity:.35;}
.empty-day p{font-size:13px;}
.repair-header{background:linear-gradient(135deg,#0c4a6e 0%,#0891b2 100%);padding:18px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;}
.repair-header-icon{width:34px;height:34px;border-radius:9px;background:rgba(255,255,255,.12);display:flex;align-items:center;justify-content:center;}
.repair-header-title{font-size:14px;font-weight:700;color:#fff;letter-spacing:-.2px;line-height:1;margin-top:2px;}
.repair-header-sub{font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.5);}
.repair-date-badge{font-size:11px;font-weight:600;color:rgba(255,255,255,.65);background:rgba(255,255,255,.1);padding:4px 10px;border-radius:99px;white-space:nowrap;}
.repair-body{padding:18px 20px;display:flex;flex-direction:column;gap:14px;}
.step-head{display:flex;align-items:center;gap:8px;margin-bottom:10px;}
.step-num{width:20px;height:20px;border-radius:50%;background:var(--cyan);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.step-num span{font-size:10px;font-weight:800;color:#fff;}
.step-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--tx3);}
.rt-label{font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--tx3);margin-bottom:5px;display:block;}
.rt-ctrl{font-family:'Inter',sans-serif;font-size:13px;width:100%;border:1.5px solid var(--bd-md);border-radius:var(--r);padding:8px 11px;color:var(--tx);background:var(--surf);transition:border-color .2s,box-shadow .2s;outline:none;}
.rt-ctrl:focus{border-color:var(--cyan);box-shadow:0 0 0 3px rgba(8,145,178,.1);}
textarea.rt-ctrl{resize:vertical;min-height:72px;}
.rt-divider{border:none;border-top:1px solid var(--bd);}
.project-preview{display:none;margin-top:10px;background:var(--cyan-bg);border:1.5px solid var(--cyan-bd);border-radius:var(--r-lg);padding:10px 14px;align-items:flex-start;gap:10px;}
.project-preview.emerg{background:var(--red-bg);border-color:var(--red-bd);}
.preview-icon{width:30px;height:30px;border-radius:8px;background:rgba(14,116,144,.12);border:1px solid var(--cyan-bd);display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.project-preview.emerg .preview-icon{background:var(--red-bg);border-color:var(--red-bd);}
.preview-job{font-size:13px;font-weight:600;color:var(--tx);}
.preview-meta{font-size:11.5px;color:var(--tx3);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.drop-zone{border:1.5px dashed var(--bd-md);border-radius:var(--r-lg);padding:18px;text-align:center;cursor:pointer;transition:border-color .15s,background .15s;background:var(--bg);}
.drop-zone:hover{border-color:var(--cyan);background:var(--cyan-bg);}
.drop-zone input[type="file"]{display:none;}
.drop-zone i{font-size:20px;color:var(--tx3);opacity:.5;display:block;margin-bottom:6px;}
.drop-zone-title{font-size:13px;font-weight:500;color:var(--tx2);}
.drop-zone-sub{font-size:11px;color:var(--tx3);margin-top:3px;}
.preview-grid{margin-top:10px;flex-wrap:wrap;gap:8px;display:none;}
.preview-thumb{position:relative;width:68px;height:68px;border-radius:8px;overflow:hidden;border:1.5px solid var(--bd);flex-shrink:0;transition:border-color .15s,transform .12s;}
.preview-thumb:hover{border-color:var(--cyan-bd);transform:scale(1.03);}
.preview-thumb img{width:100%;height:100%;object-fit:cover;display:block;}
.preview-thumb-pdf{width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;background:var(--bg);}
.btn-thumb-remove{position:absolute;top:2px;right:2px;width:18px;height:18px;border-radius:50%;background:rgba(15,23,42,.75);border:none;color:#fff;font-size:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;}
.btn-submit{display:inline-flex;align-items:center;gap:6px;font-family:'Inter',sans-serif;font-weight:700;font-size:13px;padding:9px 20px;border-radius:var(--r);border:none;background:var(--cyan);color:#fff;cursor:pointer;transition:filter .2s;box-shadow:0 4px 14px rgba(8,145,178,.3);}
.btn-submit:hover{filter:brightness(1.08);}
.sk{background:linear-gradient(90deg,var(--bg) 25%,#eaedf2 50%,var(--bg) 75%);background-size:200%;animation:sk .9s ease infinite;border-radius:4px;}
@keyframes sk{from{background-position:200% 0}to{background-position:-200% 0}}
@media(max-width:900px){.stats-grid{grid-template-columns:repeat(3,1fr);}}
@media(max-width:640px){.cal-page{padding:16px;}.stats-grid{grid-template-columns:repeat(2,1fr);}.cal-inner{padding:12px;}.drawer{width:100vw;}}
</style>

<div class="cal-page">
    <div class="topbar">
        <div class="topbar-left">
            <div style="width:36px;height:36px;background:var(--blue-bg);border-radius:9px;display:flex;align-items:center;justify-content:center;border:1px solid var(--blue-bd)">
                <i class="fas fa-calendar-days" style="font-size:15px;color:var(--blue)"></i>
            </div>
            <div>
                <div class="topbar-title">Job Calendar</div>
                <div class="topbar-sub">Your assigned jobs, emergencies &amp; repairs</div>
            </div>
        </div>
        <div class="topbar-actions">
            <a href="{{ route('jobs.create') }}" class="btn btn-primary"><i class="fas fa-plus" style="font-size:11px"></i> New Job</a>
            <a href="{{ route('emergency.form') }}" class="btn btn-danger"><i class="fas fa-circle-exclamation" style="font-size:11px"></i> Emergency</a>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat"><div class="stat-dot blue"></div><div><div class="stat-num" id="stat-jobs">—</div><div class="stat-lbl">Jobs</div></div><div class="stat-bar"><div class="stat-bar-fill blue" id="sbar-jobs" style="width:0%"></div></div></div>
        <div class="stat"><div class="stat-dot red"></div><div><div class="stat-num" id="stat-emergencies">—</div><div class="stat-lbl">Emergencies</div></div><div class="stat-bar"><div class="stat-bar-fill red" id="sbar-emerg" style="width:0%"></div></div></div>
        <div class="stat"><div class="stat-dot cyan"></div><div><div class="stat-num" id="stat-repairs">—</div><div class="stat-lbl">Repairs</div></div><div class="stat-bar"><div class="stat-bar-fill cyan" id="sbar-repairs" style="width:0%"></div></div></div>
        <div class="stat"><div class="stat-dot purple"></div><div><div class="stat-num" id="stat-approvals">—</div><div class="stat-lbl">Approvals</div></div><div class="stat-bar"><div class="stat-bar-fill purple" id="sbar-appr" style="width:0%"></div></div></div>
        <div class="stat"><div class="stat-dot gray"></div><div><div class="stat-num" id="stat-total">—</div><div class="stat-lbl">Total</div></div><div class="stat-bar"><div class="stat-bar-fill gray" id="sbar-total" style="width:100%"></div></div></div>
    </div>

    <div class="cal-search-wrap">
        <i class="fas fa-search cal-search-ico"></i>
        <input type="text" id="calSearch" class="cal-search-input" placeholder="Search by job number, company, address…">
        <button type="button" class="cal-search-clear" id="btnClearSearch" onclick="clearSearch()"><i class="fas fa-times"></i></button>
        <div style="width:1px;height:20px;background:var(--bd);margin:0 4px;flex-shrink:0;"></div>
        <div class="cal-filter-chips">
            <span class="cal-chip chip-job"    data-filter="Job Request"   onclick="toggleChip(this)"><span class="cal-chip-dot"></span> Jobs</span>
            <span class="cal-chip chip-emerg"  data-filter="Emergency"     onclick="toggleChip(this)"><span class="cal-chip-dot"></span> Emergencies</span>
            <span class="cal-chip chip-repair" data-filter="Repair Ticket" onclick="toggleChip(this)"><span class="cal-chip-dot"></span> Repairs</span>
            <span class="cal-chip chip-appr"   data-filter="Lead Approval" onclick="toggleChip(this)"><span class="cal-chip-dot"></span> Approvals</span>
        </div>
        <span class="cal-search-count" id="eventCount"></span>
    </div>

    <div class="search-notice" id="searchNotice">
        <i class="fas fa-info-circle"></i>
        <span id="searchNoticeText"></span>
        <a href="#" onclick="clearSearch();return false;">Clear</a>
    </div>

    <div class="cal-wrap">
        <div class="cal-inner"><div id="calendar"></div></div>
    </div>
</div>

{{-- DRAWER --}}
{{-- Sin backdrop: el calendario sigue siendo navegable con el drawer abierto --}}

<div class="drawer" id="mainDrawer">
    <div class="drawer-head">
        <div>
            <div class="drawer-head-date" id="drawerDateLabel">—</div>
            <div class="drawer-head-day"  id="drawerDayLabel">—</div>
        </div>
        <button class="drawer-close" onclick="closeDrawer()"><i class="fas fa-times"></i></button>
    </div>

    <div class="drawer-tabs">
        <button class="drawer-tab on" data-tab="events" onclick="switchTab('events')">
            <i class="fas fa-calendar-days"></i> Events
        </button>

    </div>

    <div class="drawer-body">

        <div class="drawer-panel on" id="panel-events">
            <div class="drawer-events" id="drawerEventsBody"></div>
        </div>

        <div class="drawer-panel" id="panel-repair">
            @if(session('repair_success'))
            <div style="margin:14px 16px 0;background:var(--green-bg);border:1px solid var(--green-bd);border-radius:var(--r);padding:10px 14px;display:flex;align-items:center;gap:8px;font-size:12.5px;color:#065f46;">
                <i class="fas fa-check-circle"></i> {{ session('repair_success') }}
            </div>
            @endif

            <form action="{{ route('repair-tickets.store') }}" method="POST" enctype="multipart/form-data" id="repairCalForm">
                @csrf
                <input type="hidden" name="repair_date" id="rtDate">
                <input type="hidden" name="status" value="open">

                <div class="repair-header">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <div class="repair-header-icon"><i class="fas fa-helmet-safety" style="color:#67e8f9;font-size:14px;"></i></div>
                        <div>
                            <div class="repair-header-sub">New</div>
                            <div class="repair-header-title">Repair Ticket</div>
                        </div>
                    </div>
                    <span class="repair-date-badge" id="rtDateLabel"></span>
                </div>

                <div class="repair-body">
                    <div>
                        <div class="step-head"><div class="step-num"><span>1</span></div><span class="step-label">Link to Project</span></div>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                            <div>
                                <label class="rt-label">Type</label>
                                <select name="reference_type" id="rtRefType" class="rt-ctrl" onchange="loadRefOptions(this.value)">
                                    <option value="" disabled selected>Select…</option>
                                    <option value="job">Job Request</option>
                                    <option value="emergency">Emergency</option>
                                </select>
                            </div>
                            <div>
                                <label class="rt-label">Job / Emergency</label>
                                <select name="reference_id" id="rtRefId" class="rt-ctrl" disabled onchange="showProjectPreview(this)">
                                    <option value="">Select type first…</option>
                                </select>
                            </div>
                        </div>
                        <div class="project-preview" id="projectPreview">
                            <div class="preview-icon"><i id="previewIcon" class="fas fa-briefcase" style="color:var(--cyan);font-size:12px;"></i></div>
                            <div style="flex:1;min-width:0;">
                                <div class="preview-job"  id="previewJobNum"></div>
                                <div class="preview-meta" id="previewCompany"></div>
                                <div class="preview-meta" id="previewAddress"></div>
                            </div>
                        </div>
                    </div>

                    <hr class="rt-divider">

                    <div>
                        <div class="step-head"><div class="step-num"><span>2</span></div><span class="step-label">Details</span></div>
                        <div style="margin-bottom:10px;">
                            <label class="rt-label">Repair Date</label>
                            <input type="date" id="rtDateDisplay" class="rt-ctrl" readonly style="background:var(--bg);color:var(--tx3);cursor:default;">
                        </div>
                        <div>
                            <label class="rt-label">Damage Description <span style="color:var(--red);">*</span></label>
                            <textarea name="description" class="rt-ctrl" rows="3" placeholder="Describe the damage or issue found…" required></textarea>
                        </div>
                    </div>

                    <hr class="rt-divider">

                    <div>
                        <div class="step-head">
                            <div class="step-num"><span>3</span></div>
                            <span class="step-label">Photos <span style="font-size:10px;font-weight:400;text-transform:none;letter-spacing:0;color:var(--tx3);margin-left:4px;">(optional)</span></span>
                        </div>
                        <div class="drop-zone" id="rtDropZone" onclick="document.getElementById('rtFileInput').click()" ondragover="rtDragOver(event)" ondragleave="rtDragLeave(event)" ondrop="rtDrop(event)">
                            <i class="fas fa-cloud-arrow-up"></i>
                            <div class="drop-zone-title">Click or drag photos here</div>
                            <div class="drop-zone-sub">JPG, PNG, WEBP, PDF — multiple files allowed</div>
                            <input type="file" id="rtFileInput" name="photos[]" accept="image/*,.pdf" multiple onchange="rtHandleFiles(this.files)">
                        </div>
                        <div class="preview-grid" id="rtPreviewGrid"></div>
                    </div>

                    <div style="display:flex;align-items:center;justify-content:space-between;padding-top:12px;border-top:1px solid var(--bd);">
                        <a href="{{ route('repair-tickets.index') }}" style="font-size:12px;font-weight:600;color:var(--cyan);display:flex;align-items:center;gap:5px;opacity:.8;transition:opacity .15s;" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=.8">
                            <i class="fas fa-clock-rotate-left" style="font-size:11px"></i> View history
                        </a>
                        <button type="submit" class="btn-submit"><i class="fas fa-paper-plane" style="font-size:11px"></i> Submit Ticket</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded',function(){
    const TYPE_COLORS={'Job Request':'#2563eb','Emergency':'#dc2626','Lead Approval':'#7c3aed','Repair Ticket':'#0e7490'};
    const STATUS_SOLID={pending:'#d97706',scheduled:'#2563eb',in_progress:'#7c3aed',completed:'#16a34a',cancelled:'#dc2626',emergency:'#dc2626',repair:'#0e7490',open:'#d97706',resolved:'#16a34a',closed:'#9099a8',approval:'#7c3aed'};
    const STATUS_COLORS={pending:{bg:'rgba(251,191,36,.2)',color:'#d97706'},scheduled:{bg:'rgba(37,99,235,.15)',color:'#2563eb'},in_progress:{bg:'rgba(124,58,237,.15)',color:'#7c3aed'},completed:{bg:'rgba(22,163,74,.15)',color:'#16a34a'},cancelled:{bg:'rgba(220,38,38,.15)',color:'#dc2626'},emergency:{bg:'rgba(220,38,38,.15)',color:'#dc2626'},repair:{bg:'rgba(14,116,144,.15)',color:'#0e7490'},open:{bg:'rgba(251,191,36,.2)',color:'#d97706'},resolved:{bg:'rgba(22,163,74,.15)',color:'#16a34a'},closed:{bg:'rgba(144,153,168,.2)',color:'#9099a8'},approval:{bg:'rgba(124,58,237,.15)',color:'#7c3aed'}};
    function sKey(s){return(s||'pending').toLowerCase().replace(/\s+/g,'_');}
    function accentColor(type,status){if(type==='Emergency')return'#dc2626';if(type==='Lead Approval')return'#7c3aed';if(type==='Repair Ticket')return'#0e7490';return(STATUS_COLORS[sKey(status)]||{}).color||'#9099a8';}
    function typeTag(t){if(t==='Emergency')return`<span class="ev-type-pill ev-type-emerg">Emergency</span>`;if(t==='Lead Approval')return`<span class="ev-type-pill ev-type-appr">Approval</span>`;if(t==='Repair Ticket')return`<span class="ev-type-pill ev-type-repair">Repair</span>`;return`<span class="ev-type-pill ev-type-job">Job</span>`;}
    window.allEvents=[];
    const activeFilters=new Set(['Job Request','Emergency','Repair Ticket','Lead Approval']);
    let searchQuery='';

    const calendar=new FullCalendar.Calendar(document.getElementById('calendar'),{
        initialView:'dayGridMonth',
        headerToolbar:{left:'prev,next today',center:'title',right:'dayGridMonth,timeGridWeek,listMonth'},
        height:'auto',dayMaxEvents:3,
        events:function(fetchInfo,successCallback,failureCallback){
            fetch("{{ route('calendar.data') }}")
                .then(r=>r.json())
                .then(data=>{
                    window.allEvents=Array.isArray(data.events)?data.events:[];
                    const j=data.job_count??0,em=data.emergency_count??0,rp=data.repair_count??0,ap=data.lead_approval_count??0,tot=j+em+rp+ap||1;
                    document.getElementById('stat-jobs').textContent=j;
                    document.getElementById('stat-emergencies').textContent=em;
                    document.getElementById('stat-repairs').textContent=rp;
                    document.getElementById('stat-approvals').textContent=ap;
                    document.getElementById('stat-total').textContent=window.allEvents.length;
                    document.getElementById('sbar-jobs').style.width=Math.round(j/tot*100)+'%';
                    document.getElementById('sbar-emerg').style.width=Math.round(em/tot*100)+'%';
                    document.getElementById('sbar-repairs').style.width=Math.round(rp/tot*100)+'%';
                    document.getElementById('sbar-appr').style.width=Math.round(ap/tot*100)+'%';
                    renderFilteredEvents(successCallback);
                }).catch(err=>failureCallback(err));
        },
        eventContent:function(arg){
            const p=arg.event.extendedProps||{};
            const status=sKey(p.status||'');
            const solidColor=STATUS_SOLID[status]||'#9099a8';
            const sc=STATUS_COLORS[status]||{bg:'rgba(255,255,255,.15)',color:'#fff'};
            const isList=['listMonth','listWeek','listDay'].includes(arg.view.type);
            const typeColor=TYPE_COLORS[p.type]||'#0d0f12';
            const w=document.createElement('div');
            w.style.cssText='display:flex;flex-direction:column;overflow:hidden;width:100%;padding:2px 4px;gap:1px;';
            const title=document.createElement('span');
            title.style.cssText='overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;line-height:1.3;'+(isList?'font-size:0.75rem;color:'+typeColor+';':'font-size:0.67rem;color:#fff;');
            title.textContent=arg.event.title;
            const badge=document.createElement('span');
            badge.style.cssText='display:inline-flex;align-items:center;font-size:0.57rem;font-weight:700;text-transform:uppercase;letter-spacing:0.05em;padding:1px 5px;border-radius:99px;width:fit-content;'+(isList?'background:'+sc.bg+';color:'+sc.color+';':'background:'+solidColor+';color:#fff;');
            badge.textContent=status.replace('_',' ');
            w.appendChild(title);w.appendChild(badge);
            return{domNodes:[w]};
        },
        eventClick:function(info){info.jsEvent.preventDefault();openDrawer(info.event.startStr.substring(0,10));},
        dateClick:function(info){openDrawer(info.dateStr);},
        moreLinkClick:function(info){openDrawer(info.date.toISOString().substring(0,10));return'stop';},
    });
    calendar.render();
    window.refreshCalendar=()=>calendar.refetchEvents();

    function getFiltered(){
        if(!searchQuery)return window.allEvents.filter(ev=>activeFilters.has(ev.type));
        const q=searchQuery;
        const direct=window.allEvents.filter(ev=>{if(!activeFilters.has(ev.type))return false;return(ev.title||'').toLowerCase().includes(q)||(ev.extendedProps?.company||'').toLowerCase().includes(q)||(ev.extendedProps?.address||'').toLowerCase().includes(q);});
        const urls=new Set(direct.map(ev=>ev.url).filter(Boolean));
        const res=new Map();
        direct.forEach(ev=>res.set(ev.title+'|'+ev.start,ev));
        window.allEvents.forEach(ev=>{if(!activeFilters.has(ev.type))return;if(ev.url&&urls.has(ev.url))res.set(ev.title+'|'+ev.start,ev);});
        return Array.from(res.values());
    }

    function renderFilteredEvents(successCallback){
        const filtered=getFiltered();
        const count=filtered.length;
        const countEl=document.getElementById('eventCount');
        countEl.textContent=count+' event'+(count!==1?'s':'');
        countEl.style.display=(searchQuery||activeFilters.size<4)?'inline-flex':'none';
        const mapped=filtered.map(ev=>({...ev,backgroundColor:TYPE_COLORS[ev.type]||ev.color||'#9099a8',borderColor:TYPE_COLORS[ev.type]||ev.color||'#9099a8',textColor:'#fff'}));
        if(successCallback){successCallback(mapped);}
        else{
            calendar.getEventSources().forEach(s=>s.remove());
            calendar.addEventSource(mapped);
            const notice=document.getElementById('searchNotice');
            if(searchQuery){calendar.changeView('listMonth');notice.classList.add('visible');document.getElementById('searchNoticeText').textContent=`${count} event${count!==1?'s':''} found for "${searchQuery}" across all months`;}
            else{calendar.changeView('dayGridMonth');calendar.today();notice.classList.remove('visible');}
        }
    }

    window.toggleChip=function(chip){
        const f=chip.dataset.filter;
        if(activeFilters.has(f)){activeFilters.delete(f);chip.classList.add('off');}
        else{activeFilters.add(f);chip.classList.remove('off');}
        renderFilteredEvents(null);
    };
    document.getElementById('calSearch').addEventListener('input',function(){
        searchQuery=this.value.toLowerCase().trim();
        document.getElementById('btnClearSearch').style.display=searchQuery?'flex':'none';
        renderFilteredEvents(null);
    });
    window.clearSearch=function(){
        document.getElementById('calSearch').value='';searchQuery='';
        document.getElementById('btnClearSearch').style.display='none';
        renderFilteredEvents(null);
    };

    window.openDrawer=function(dateStr){
        const evs=(window.allEvents||[]).filter(ev=>ev.start&&ev.start.startsWith(dateStr));
        const d=new Date(dateStr+'T00:00:00');
        document.getElementById('drawerDateLabel').textContent=d.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'});
        document.getElementById('drawerDayLabel').textContent=d.toLocaleDateString('en-US',{weekday:'long'});
        document.getElementById('rtDate').value=dateStr;
        document.getElementById('rtDateDisplay').value=dateStr;
        document.getElementById('rtDateLabel').textContent=d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
        const body=document.getElementById('drawerEventsBody');
        body.innerHTML='';
        if(!evs.length){
            body.innerHTML=`<div class="empty-day"><i class="fas fa-calendar-days"></i><p>No events on this date.</p></div>`;
        }else{
            evs.forEach(ev=>{
                const p=ev.extendedProps||{};
                const acc=accentColor(ev.type,p.status);
                const sk=sKey(p.status||ev.type);
                const solidColor=STATUS_SOLID[sk]||'#9099a8';
                const card=document.createElement('div');
                card.className='ev-card';
                card.innerHTML=`<div class="ev-card-top"><div class="ev-card-bar" style="background:${acc}"></div><div class="ev-card-body"><div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:6px;"><div class="ev-card-title">${ev.title||'—'}</div>${typeTag(ev.type)}</div><div class="ev-card-meta">${p.company?`<span class="ev-card-meta-item"><i class="fas fa-building"></i>${p.company}</span>`:''} ${p.address?`<span class="ev-card-meta-item"><i class="fas fa-map-marker-alt"></i>${p.address}</span>`:''}</div></div></div><div class="ev-card-footer"><span class="ev-status-pill" style="background:${solidColor}">${sk.replace('_',' ')}</span>${ev.url?`<a href="${ev.url}" class="btn-open">Open <i class="fas fa-arrow-right" style="font-size:10px"></i></a>`:''}</div>`;
                body.appendChild(card);
            });
        }
        const jobs=evs.filter(ev=>ev.type==='Job Request');
        const emergs=evs.filter(ev=>ev.type==='Emergency');
        const single=(jobs.length===1&&emergs.length===0)?{type:'job',ev:jobs[0]}:(emergs.length===1&&jobs.length===0)?{type:'emergency',ev:emergs[0]}:null;
        if(single){document.getElementById('rtRefType').value=single.type;loadRefOptions(single.type,single.ev.url);}
        else{document.getElementById('rtRefType').value='';const sel=document.getElementById('rtRefId');sel.innerHTML='<option value="">Select type first…</option>';sel.disabled=true;document.getElementById('projectPreview').style.display='none';}
        switchTab('events');
        document.getElementById('mainDrawer').classList.add('open');
    };

    window.closeDrawer=function(){
        document.getElementById('mainDrawer').classList.remove('open');
        document.body.style.overflow='';
        setTimeout(()=>{
            rtFiles=[];
            const grid=document.getElementById('rtPreviewGrid');
            grid.innerHTML='';grid.style.display='none';
            document.getElementById('rtDropZone').style.borderColor='';
            document.getElementById('rtDropZone').style.background='';
            document.getElementById('rtRefType').value='';
            const sel=document.getElementById('rtRefId');
            sel.innerHTML='<option value="">Select type first…</option>';
            sel.disabled=true;
            document.getElementById('projectPreview').style.display='none';
            document.getElementById('repairCalForm').reset();
        },300);
    };

    document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDrawer();});
});

const _refCache={};
let rtFiles=[];

function switchTab(tab){
    document.querySelectorAll('.drawer-tab').forEach(t=>t.classList.remove('on'));
    document.querySelectorAll('.drawer-panel').forEach(p=>p.classList.remove('on'));
    document.querySelector(`.drawer-tab[data-tab="${tab}"]`).classList.add('on');
    document.getElementById(`panel-${tab}`).classList.add('on');
}

async function loadRefOptions(type,preSelectUrl=null){
    const sel=document.getElementById('rtRefId');
    sel.disabled=true;sel.innerHTML='<option value="">Loading…</option>';
    document.getElementById('projectPreview').style.display='none';
    try{
        if(!_refCache[type]){_refCache[type]=await fetch(`/repair-tickets/references?type=${type}`).then(r=>r.json());}
        const data=_refCache[type];
        sel.innerHTML='<option value="" disabled selected>Select…</option>';
        data.forEach(item=>{const opt=document.createElement('option');opt.value=item.id;opt.textContent=item.label;opt.dataset.company=item.company??'';opt.dataset.address=item.address??'';sel.appendChild(opt);});
        sel.disabled=false;
        if(preSelectUrl){const id=preSelectUrl.match(/\/(\d+)(?:\?|$)/)?.[1];if(id){const opt=[...sel.options].find(o=>o.value===id);if(opt){sel.value=id;showProjectPreview(sel);}}}
    }catch{sel.innerHTML='<option value="">Error loading</option>';}
}

function showProjectPreview(sel){
    const opt=sel.options[sel.selectedIndex];
    const preview=document.getElementById('projectPreview');
    if(!opt||!opt.value){preview.style.display='none';return;}
    const type=document.getElementById('rtRefType').value;
    const icon=document.getElementById('previewIcon');
    if(type==='emergency'){icon.className='fas fa-exclamation-circle';icon.style.color='var(--red)';preview.classList.add('emerg');}
    else{icon.className='fas fa-briefcase';icon.style.color='var(--cyan)';preview.classList.remove('emerg');}
    document.getElementById('previewJobNum').textContent=opt.textContent;
    document.getElementById('previewCompany').textContent=opt.dataset.company||'';
    document.getElementById('previewAddress').textContent=opt.dataset.address||'';
    preview.style.display='flex';
}

function rtHandleFiles(incoming){Array.from(incoming).forEach(file=>{rtFiles.push(file);rtRenderPreview(file,rtFiles.length-1);});rtSyncInput();const zone=document.getElementById('rtDropZone');zone.style.borderColor='var(--cyan)';zone.style.background='var(--cyan-bg)';}
function rtRenderPreview(file,index){const grid=document.getElementById('rtPreviewGrid');grid.style.display='flex';const wrap=document.createElement('div');wrap.id='rt-prev-'+index;wrap.className='preview-thumb';if(file.type==='application/pdf'){wrap.innerHTML=`<div class="preview-thumb-pdf"><i class="fas fa-file-pdf" style="font-size:18px;color:var(--red);"></i><span style="font-size:9px;font-weight:600;color:var(--tx3);width:90%;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${file.name}</span></div>`;}else{const img=document.createElement('img');img.src=URL.createObjectURL(file);wrap.appendChild(img);}const btn=document.createElement('button');btn.type='button';btn.className='btn-thumb-remove';btn.innerHTML='<i class="fas fa-times" style="font-size:9px"></i>';btn.onclick=()=>rtRemoveFile(index);wrap.appendChild(btn);grid.appendChild(wrap);}
function rtRemoveFile(index){rtFiles[index]=null;const el=document.getElementById('rt-prev-'+index);if(el)el.remove();if(rtFiles.every(f=>f===null)){const zone=document.getElementById('rtDropZone');zone.style.borderColor='';zone.style.background='';document.getElementById('rtPreviewGrid').style.display='none';}rtSyncInput();}
function rtSyncInput(){const dt=new DataTransfer();rtFiles.filter(Boolean).forEach(f=>dt.items.add(f));document.getElementById('rtFileInput').files=dt.files;}
function rtDragOver(e){e.preventDefault();e.currentTarget.style.borderColor='var(--cyan)';e.currentTarget.style.background='var(--cyan-bg)';}
function rtDragLeave(e){if(!rtFiles.filter(Boolean).length){e.currentTarget.style.borderColor='';e.currentTarget.style.background='';}}
function rtDrop(e){e.preventDefault();rtHandleFiles(e.dataTransfer.files);}
</script>
@extends('layouts.app')

@section('content')

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    :root {
        --slate-900: #0f172a;
        --slate-800: #1e293b;
        --slate-700: #334155;
        --slate-600: #475569;
        --slate-400: #94a3b8;
        --slate-200: #e2e8f0;
        --slate-100: #f1f5f9;
        --white:       #ffffff;
        --accent:      #3b82f6;
        --accent-dark: #1d4ed8;
        --accent-light:#eff6ff;
        --success:     #10b981;
        --danger:      #ef4444;
        --warning:     #f59e0b;
        --repair:      #0891b2;
    }

    .job-page { font-family:'Montserrat',sans-serif; background:var(--slate-100); min-height:100vh; padding:2rem 1rem 3rem; }

    .detail-hero { background:var(--slate-900); border-radius:16px; padding:1.75rem 2.5rem; margin-bottom:1.75rem; display:flex; align-items:center; justify-content:space-between; gap:1.25rem; flex-wrap:wrap; position:relative; overflow:hidden; }
    .detail-hero::after { content:''; position:absolute; left:0; top:0; bottom:0; width:4px; background:var(--accent); border-radius:16px 0 0 16px; }
    .hero-eyebrow { font-size:0.68rem; font-weight:700; letter-spacing:0.1em; text-transform:uppercase; color:var(--slate-400); margin-bottom:0.3rem; }
    .hero-title { font-family:'Montserrat',sans-serif; font-size:1.4rem; font-weight:800; color:var(--white); margin:0 0 0.25rem; letter-spacing:-0.02em; line-height:1.2; }
    .hero-subtitle { font-size:0.8rem; color:var(--slate-400); }
    .hero-actions { display:flex; gap:0.65rem; flex-wrap:wrap; }

    .btn-hero { display:inline-flex; align-items:center; gap:0.4rem; font-family:'Montserrat',sans-serif; font-weight:600; font-size:0.8rem; padding:0.45rem 1rem; border-radius:8px; text-decoration:none; white-space:nowrap; transition:filter 0.2s,transform 0.15s; border:none; cursor:pointer; }
    .btn-hero:hover { filter:brightness(1.1); transform:translateY(-1px); }
    .btn-back   { background:rgba(255,255,255,0.08); color:var(--slate-400); border:1px solid rgba(255,255,255,0.1); }
    .btn-back:hover { color:var(--white); }
    .btn-edit   { background:var(--white); color:var(--slate-900); }
    .btn-edit:hover { color:var(--slate-900); }
    .btn-repair { background:rgba(8,145,178,0.15); color:#67e8f9; border:1px solid rgba(8,145,178,0.3); }
    .btn-repair:hover { color:#a5f3fc; }
    .btn-delete { background:rgba(239,68,68,0.15); color:#fca5a5; border:1px solid rgba(239,68,68,0.3); }
    .btn-delete:hover { color:#fca5a5; }

    .detail-card { background:var(--white); border-radius:14px; box-shadow:0 2px 16px rgba(15,23,42,0.07); margin-bottom:1.5rem; overflow:hidden; }
    .detail-card-header { padding:1rem 1.5rem; border-bottom:1px solid var(--slate-200); display:flex; align-items:center; gap:0.6rem; background:linear-gradient(to right,var(--accent-light),transparent); }
    .detail-card-header h5 { font-family:'Montserrat',sans-serif; font-size:0.88rem; font-weight:700; color:var(--slate-900); margin:0; }
    .detail-card-header i { color:var(--accent); font-size:0.95rem; }
    .detail-card-body { padding:1.5rem; }

    .detail-row { display:flex; flex-direction:column; padding:0.75rem 0; border-bottom:1px solid var(--slate-200); }
    .detail-row:last-child { border-bottom:none; }
    .detail-label { font-size:0.7rem; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; color:var(--slate-400); margin-bottom:0.2rem; display:flex; align-items:center; gap:0.35rem; }
    .detail-value { font-size:0.9rem; font-weight:500; color:var(--slate-800); line-height:1.5; }

    .sub-heading { font-family:'Montserrat',sans-serif; font-size:0.72rem; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; color:var(--slate-400); margin:1.25rem 0 0.75rem; padding-bottom:0.4rem; border-bottom:1px dashed var(--slate-200); }
    .sub-heading:first-child { margin-top:0; }

    .status-badge { display:inline-flex; align-items:center; gap:0.4rem; font-size:0.7rem; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; padding:0.28rem 0.8rem; border-radius:99px; border:2px solid; }
    .badge-pending     { color:var(--warning);  border-color:var(--warning);  background:#fffbeb; }
    .badge-scheduled   { color:var(--accent);   border-color:var(--accent);   background:#eff6ff; }
    .badge-in_progress { color:#8b5cf6;         border-color:#8b5cf6;         background:#f5f3ff; }
    .badge-completed   { color:var(--success);  border-color:var(--success);  background:#ecfdf5; }
    .badge-cancelled   { color:var(--danger);   border-color:var(--danger);   background:#fff1f2; }

    .yn-pill { display:inline-flex; align-items:center; gap:0.3rem; font-size:0.7rem; font-weight:700; text-transform:uppercase; letter-spacing:0.04em; padding:0.2rem 0.65rem; border-radius:99px; }
    .yn-yes    { background:#ecfdf5; color:var(--success); }
    .yn-no     { background:var(--slate-100); color:var(--slate-400); }
    .yn-active { background:#fff1f2; color:var(--danger); }

    .instructions-box { background:var(--slate-100); border:1px solid var(--slate-200); border-left:3px solid var(--accent); border-radius:0 10px 10px 0; padding:0.85rem 1rem; font-size:0.87rem; color:var(--slate-700); line-height:1.6; }

    .team-member { display:flex; align-items:center; gap:0.85rem; padding:0.8rem 1rem; border-radius:10px; background:var(--slate-100); border:1px solid var(--slate-200); margin-bottom:0.6rem; transition:transform 0.15s; }
    .team-member:hover { transform:translateX(3px); }
    .team-avatar { width:38px; height:38px; border-radius:9px; display:flex; align-items:center; justify-content:center; font-family:'Montserrat',sans-serif; font-weight:800; font-size:0.85rem; color:var(--white); flex-shrink:0; background:linear-gradient(135deg,var(--slate-700),var(--slate-900)); }
    .team-name { font-weight:600; font-size:0.85rem; color:var(--slate-900); }
    .team-role { font-size:0.67rem; font-weight:700; text-transform:uppercase; letter-spacing:0.06em; color:var(--slate-400); margin-top:1px; }
    .team-badge { margin-left:auto; font-size:0.63rem; font-weight:700; text-transform:uppercase; letter-spacing:0.05em; padding:0.18rem 0.55rem; border-radius:99px; background:var(--slate-200); color:var(--slate-700); flex-shrink:0; }

    .file-group-title { font-family:'Montserrat',sans-serif; font-size:0.75rem; font-weight:700; color:var(--slate-600); text-transform:uppercase; letter-spacing:0.05em; margin:1rem 0 0.55rem; display:flex; align-items:center; gap:0.4rem; }
    .file-group-title:first-child { margin-top:0; }
    .file-item { display:flex; align-items:center; gap:0.7rem; padding:0.7rem 0.9rem; border-radius:9px; background:var(--slate-100); border:1px solid var(--slate-200); margin-bottom:0.45rem; transition:background 0.15s; }
    .file-item:hover { background:#eff6ff; }
    .file-icon { width:32px; height:32px; border-radius:7px; display:flex; align-items:center; justify-content:center; flex-shrink:0; font-size:0.9rem; }
    .file-icon.pdf   { background:#fee2e2; color:var(--danger); }
    .file-icon.img   { background:#dbeafe; color:var(--accent); }
    .file-icon.xls   { background:#dcfce7; color:var(--success); }
    .file-icon.doc   { background:#e0f2fe; color:#0284c7; }
    .file-icon.zip   { background:#fef9c3; color:var(--warning); }
    .file-icon.other { background:var(--slate-200); color:var(--slate-600); }
    .file-info { flex-grow:1; min-width:0; }
    .file-name { font-size:0.82rem; font-weight:500; color:var(--slate-800); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    .file-ext  { font-size:0.67rem; font-weight:700; text-transform:uppercase; color:var(--slate-400); letter-spacing:0.05em; }
    .file-btns { display:flex; gap:0.35rem; flex-shrink:0; }
    .btn-file { font-size:0.72rem; font-weight:600; padding:0.27rem 0.65rem; border-radius:6px; text-decoration:none; white-space:nowrap; transition:background 0.2s; }
    .btn-file-view     { background:var(--slate-900); color:var(--white); }
    .btn-file-view:hover { background:var(--accent-dark); color:var(--white); }
    .btn-file-dl       { background:var(--slate-200); color:var(--slate-700); }
    .btn-file-dl:hover { background:var(--slate-300); color:var(--slate-900); }
    .empty-msg { text-align:center; padding:1.5rem; color:var(--slate-400); font-size:0.82rem; font-style:italic; }

    /* ── Repair modal ── */
    .rt-label { font-size:0.67rem; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; color:#64748b; margin-bottom:0.28rem; display:block; }
    .rt-ctrl { font-family:'Montserrat',sans-serif; font-size:0.86rem; width:100%; border:1.5px solid var(--slate-200); border-radius:9px; padding:0.52rem 0.85rem; color:var(--slate-900); background:var(--white); transition:border-color 0.2s,box-shadow 0.2s; }
    .rt-ctrl:focus { border-color:var(--repair); box-shadow:0 0 0 3px rgba(8,145,178,0.1); outline:none; }
    textarea.rt-ctrl { resize:vertical; min-height:80px; }
    .rt-step-head { display:flex; align-items:center; gap:0.5rem; margin-bottom:0.65rem; }
    .rt-step-num { width:20px; height:20px; border-radius:50%; background:var(--repair); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .rt-step-num span { font-size:0.6rem; font-weight:800; color:#fff; }
    .rt-step-label { font-size:0.72rem; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; color:#64748b; }
    .rt-divider { border:none; border-top:1px solid var(--slate-200); margin:0.9rem 0; }
    .btn-rt-submit { display:inline-flex; align-items:center; gap:0.4rem; font-family:'Montserrat',sans-serif; font-weight:700; font-size:0.85rem; padding:0.6rem 1.6rem; border-radius:9px; border:none; background:var(--repair); color:#fff; cursor:pointer; transition:filter 0.2s; box-shadow:0 4px 14px rgba(8,145,178,0.3); }
    .btn-rt-submit:hover { filter:brightness(1.08); }

    @media (max-width:576px) {
        .detail-hero { padding:1.25rem 1.5rem; }
        .hero-title  { font-size:1.2rem; }
        .detail-card-body { padding:1.1rem; }
    }
</style>

<div class="job-page">
    <div class="container-xl px-0">

        {{-- Hero --}}
        <div class="detail-hero">
            <div>
                <div class="hero-eyebrow"><i class="bi bi-briefcase me-1"></i> Job Request #{{ $job->id }}</div>
                <h1 class="hero-title">{{ $job->job_number_name }}</h1>
                <div class="hero-subtitle">
                    <i class="bi bi-building me-1"></i> {{ $job->company_name }}
                    &nbsp;·&nbsp;
                    <i class="bi bi-calendar3 me-1"></i> Created {{ $job->created_at->format('M d, Y') }}
                </div>
            </div>
            <div class="hero-actions">
                <a href="{{ route('calendar.view') }}" class="btn-hero btn-back">
                    <i class="bi bi-arrow-left"></i> Back
                </a>
                <a href="{{ route('jobs.edit', $job->id) }}" class="btn-hero btn-edit">
                    <i class="bi bi-pencil-square"></i> Edit
                </a>
                <button type="button" class="btn-hero btn-repair" data-bs-toggle="modal" data-bs-target="#repairModal">
                    <i class="bi bi-tools"></i> Repair Ticket
                </button>
                <form id="delete-form-{{ $job->id }}" action="{{ route('jobs.destroy', $job->id) }}" method="POST" class="d-inline">
                    @csrf @method('DELETE')
                    <button type="button" class="btn-hero btn-delete" onclick="confirmJobDelete({{ $job->id }})">
                        <i class="bi bi-trash"></i> Delete
                    </button>
                </form>
            </div>
        </div>

        <div class="row g-4">

            {{-- LEFT --}}
            <div class="col-lg-8">

                <div class="detail-card">
                    <div class="detail-card-header">
                        <i class="bi bi-info-circle-fill"></i>
                        <h5>General Information</h5>
                    </div>
                    <div class="detail-card-body">
                        <div class="row g-0">
                            <div class="col-md-6 pe-md-4">
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-calendar-event"></i> Install Date</span>
                                    <span class="detail-value">{{ $job->install_date_requested }}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-building"></i> Company</span>
                                    <span class="detail-value">{{ $job->company_name }}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-person"></i> Representative</span>
                                    <span class="detail-value">{{ $job->company_rep }}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-telephone"></i> Phone</span>
                                    <span class="detail-value">{{ $job->company_rep_phone }}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-envelope"></i> Email</span>
                                    <span class="detail-value">{{ $job->company_rep_email }}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-flag"></i> Status</span>
                                    <span class="detail-value">
                                        @php $statusKey = strtolower(str_replace(' ','_',$job->status ?? 'pending')); @endphp
                                        <span class="status-badge badge-{{ $statusKey }}">
                                            <i class="bi {{ match($statusKey) {
                                                'completed'   => 'bi-check-circle-fill',
                                                'in_progress' => 'bi-tools',
                                                'scheduled'   => 'bi-calendar-check',
                                                'cancelled'   => 'bi-x-circle',
                                                default       => 'bi-clock'
                                            } }}"></i>
                                            {{ ucfirst(str_replace('_',' ',$statusKey)) }}
                                        </span>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-6 ps-md-4">
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-person-badge"></i> Customer</span>
                                    <span class="detail-value">{{ $job->customer_first_name }} {{ $job->customer_last_name }}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-phone"></i> Customer Phone</span>
                                    <span class="detail-value">{{ $job->customer_phone_number }}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-geo-alt"></i> Job Address</span>
                                    <span class="detail-value">
                                        {{ $job->job_address_street_address }}
                                        @if($job->job_address_street_address_line_2)<br>{{ $job->job_address_street_address_line_2 }}@endif
                                        <br>{{ $job->job_address_city }}, {{ $job->job_address_state }} {{ $job->job_address_zip_code }}
                                    </span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-truck"></i> Delivery Date</span>
                                    <span class="detail-value">{{ $job->delivery_date ?? '—' }}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label"><i class="bi bi-search"></i> Mid Roof Inspection</span>
                                    <span class="detail-value">{{ $job->mid_roof_inspection ?? '—' }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="detail-card">
                    <div class="detail-card-header">
                        <i class="bi bi-clipboard2-data-fill"></i>
                        <h5>Project Details</h5>
                    </div>
                    <div class="detail-card-body">
                        <div class="row g-0">
                            <div class="col-md-6 pe-md-4">
                                <div class="sub-heading"><i class="bi bi-box-seam me-1"></i> Materials Ordered</div>
                                <div class="detail-row"><span class="detail-label">Starter Bundles</span><span class="detail-value">{{ $job->starter_bundles_ordered ?? '—' }}</span></div>
                                <div class="detail-row"><span class="detail-label">Hip & Ridge</span><span class="detail-value">{{ $job->hip_and_ridge_ordered ?? '—' }}</span></div>
                                <div class="detail-row"><span class="detail-label">Field Shingles</span><span class="detail-value">{{ $job->field_shingle_bundles_ordered ?? '—' }}</span></div>
                                <div class="detail-row"><span class="detail-label">Modified Bitumen Cap Rolls</span><span class="detail-value">{{ $job->modified_bitumen_cap_rolls_ordered ?? '—' }}</span></div>
                            </div>
                            <div class="col-md-6 ps-md-4">
                                <div class="sub-heading"><i class="bi bi-tools me-1"></i> Work Specifications</div>
                                <div class="detail-row"><span class="detail-label">Shingle Layers to Remove</span><span class="detail-value">{{ $job->asphalt_shingle_layers_to_remove ?? '—' }}</span></div>
                                <div class="detail-row">
                                    <span class="detail-label">Siding Replacement</span>
                                    <span class="detail-value"><span class="yn-pill {{ $job->siding_being_replaced ? 'yn-yes' : 'yn-no' }}"><i class="bi {{ $job->siding_being_replaced ? 'bi-check-lg' : 'bi-dash' }}"></i>{{ $job->siding_being_replaced ? 'Yes' : 'No' }}</span></span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Re-deck</span>
                                    <span class="detail-value"><span class="yn-pill {{ $job->re_deck ? 'yn-yes' : 'yn-no' }}"><i class="bi {{ $job->re_deck ? 'bi-check-lg' : 'bi-dash' }}"></i>{{ $job->re_deck ? 'Yes' : 'No' }}</span></span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Skylights Replace</span>
                                    <span class="detail-value"><span class="yn-pill {{ $job->skylights_replace ? 'yn-yes' : 'yn-no' }}"><i class="bi {{ $job->skylights_replace ? 'bi-check-lg' : 'bi-dash' }}"></i>{{ $job->skylights_replace ? 'Yes' : 'No' }}</span></span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Gutters</span>
                                    <span class="detail-value" style="display:flex;gap:.4rem;flex-wrap:wrap;">
                                        <span class="yn-pill {{ $job->gutter_remove ? 'yn-yes' : 'yn-no' }}">Remove: {{ $job->gutter_remove ? 'Yes' : 'No' }}</span>
                                        <span class="yn-pill {{ $job->gutter_detached_and_reset ? 'yn-yes' : 'yn-no' }}">Reset: {{ $job->gutter_detached_and_reset ? 'Yes' : 'No' }}</span>
                                    </span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Satellite</span>
                                    <span class="detail-value" style="display:flex;gap:.4rem;flex-wrap:wrap;">
                                        <span class="yn-pill {{ $job->satellite_remove ? 'yn-yes' : 'yn-no' }}">Remove: {{ $job->satellite_remove ? 'Yes' : 'No' }}</span>
                                        <span class="yn-pill {{ $job->satellite_goes_in_the_trash ? 'yn-active' : 'yn-no' }}">Trash: {{ $job->satellite_goes_in_the_trash ? 'Yes' : 'No' }}</span>
                                    </span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Stop Work Request</span>
                                    <span class="detail-value"><span class="yn-pill {{ $job->stop_work_request ? 'yn-active' : 'yn-no' }}"><i class="bi {{ $job->stop_work_request ? 'bi-exclamation-triangle-fill' : 'bi-check-circle' }}"></i>{{ $job->stop_work_request ? 'Active' : 'None' }}</span></span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Material Verification</span>
                                    <span class="detail-value"><span class="yn-pill {{ $job->material_verification ? 'yn-yes' : 'yn-no' }}"><i class="bi {{ $job->material_verification ? 'bi-check-circle-fill' : 'bi-hourglass' }}"></i>{{ $job->material_verification ? 'Verified' : 'Pending' }}</span></span>
                                </div>
                            </div>
                        </div>
                        @if($job->special_instructions)
                            <div class="sub-heading mt-3"><i class="bi bi-chat-left-text me-1"></i> Special Instructions</div>
                            <div class="instructions-box">{{ $job->special_instructions }}</div>
                        @endif
                    </div>
                </div>

            </div>

            {{-- RIGHT --}}
            <div class="col-lg-4">

                <div class="detail-card">
                    <div class="detail-card-header"><i class="bi bi-people-fill"></i><h5>Assigned Team</h5></div>
                    <div class="detail-card-body">
                        @forelse($job->teamMembers as $member)
                            <div class="team-member">
                                <div class="team-avatar">{{ strtoupper(substr($member->name, 0, 2)) }}</div>
                                <div>
                                    <div class="team-name">{{ $member->name }}</div>
                                    <div class="team-role">{{ ucfirst(str_replace('_',' ',$member->role)) }}</div>
                                </div>
                                <span class="team-badge">{{ $member->role }}</span>
                            </div>
                        @empty
                            <div class="empty-msg">No team members assigned.</div>
                        @endforelse
                    </div>
                </div>

                <div class="detail-card">
                    <div class="detail-card-header"><i class="bi bi-paperclip"></i><h5>Attachments</h5></div>
                    <div class="detail-card-body">
                        @php
                            $categories = [
                                ['label'=>'Aerial Measurements','icon'=>'bi-map',        'data'=>$job->aerial_measurement],
                                ['label'=>'Material Orders',    'icon'=>'bi-cart-check',  'data'=>$job->material_order],
                                ['label'=>'Other Files',        'icon'=>'bi-file-earmark','data'=>$job->file_upload],
                            ];
                            $hasAny = false;
                        @endphp
                        @foreach($categories as $cat)
                            @if(!empty($cat['data']))
                                @php
                                    $hasAny = true;
                                    $raw   = $cat['data'];
                                    if (is_string($raw)) $raw = json_decode($raw, true) ?? [];
                                    $files = is_array($raw) ? $raw : [$raw];
                                @endphp
                                <div class="file-group-title"><i class="bi {{ $cat['icon'] }}"></i> {{ $cat['label'] }}</div>
                                @foreach($files as $file)
                                    @php
                                        $path      = is_array($file) ? ($file['path'] ?? '') : $file;
                                        $filename  = is_array($file) ? ($file['original_name'] ?? basename($path)) : basename($path);
                                        $ext       = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                                        $url       = asset('storage/'.$path);
                                        $iconClass = match(true) {
                                            $ext==='pdf'                                => 'pdf',
                                            in_array($ext,['jpg','jpeg','png','gif','webp']) => 'img',
                                            in_array($ext,['xlsx','xls','csv'])         => 'xls',
                                            in_array($ext,['doc','docx'])               => 'doc',
                                            $ext==='zip'                                => 'zip',
                                            default                                     => 'other',
                                        };
                                        $iconBi = match($iconClass) {
                                            'pdf'   => 'bi-file-pdf-fill',
                                            'img'   => 'bi-file-image-fill',
                                            'xls'   => 'bi-file-spreadsheet-fill',
                                            'doc'   => 'bi-file-word-fill',
                                            'zip'   => 'bi-file-zip-fill',
                                            default => 'bi-file-earmark-fill',
                                        };
                                    @endphp
                                    <div class="file-item">
                                        <div class="file-icon {{ $iconClass }}"><i class="bi {{ $iconBi }}"></i></div>
                                        <div class="file-info">
                                            <div class="file-name">{{ $filename }}</div>
                                            <div class="file-ext">{{ $ext }}</div>
                                        </div>
                                        <div class="file-btns">
                                            <a href="{{ $url }}" target="_blank" class="btn-file btn-file-view"><i class="bi bi-eye"></i></a>
                                            <a href="{{ $url }}" download        class="btn-file btn-file-dl"><i class="bi bi-download"></i></a>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                        @endforeach
                        @if(!$hasAny)<div class="empty-msg">No attachments for this job.</div>@endif
                    </div>
                </div>

                {{-- Repair history --}}
                <div class="detail-card">
                    <div class="detail-card-header" style="background:linear-gradient(to right,#ecfeff,transparent);">
                        <i class="bi bi-tools" style="color:var(--repair);"></i>
                        <h5>Repair History</h5>
                        <a href="{{ route('repair-tickets.index', ['ref_type'=>'job','ref_id'=>$job->id]) }}"
                           style="margin-left:auto;font-size:0.72rem;font-weight:600;color:var(--repair);text-decoration:none;">
                            View all
                        </a>
                    </div>
                    <div class="detail-card-body" style="padding:1rem 1.5rem;">
                        @forelse($job->repairTickets()->latest('repair_date')->take(3)->get() as $rt)
                            @php
                                $sc = match($rt->status) {
                                    'open'        => ['bg'=>'#fffbeb','color'=>'#b45309'],
                                    'in_progress' => ['bg'=>'#f5f3ff','color'=>'#6d28d9'],
                                    'resolved'    => ['bg'=>'#ecfdf5','color'=>'#047857'],
                                    default       => ['bg'=>'#f1f5f9','color'=>'#64748b'],
                                };
                            @endphp
                            <div style="display:flex;align-items:flex-start;gap:0.65rem;padding:0.65rem 0;border-bottom:1px solid var(--slate-200);">
                                <div style="width:28px;height:28px;border-radius:6px;background:#ecfeff;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                    <i class="bi bi-tools" style="font-size:0.75rem;color:var(--repair);"></i>
                                </div>
                                <div style="flex:1;min-width:0;">
                                    <div style="font-size:0.8rem;font-weight:600;color:var(--slate-800);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                                        {{ $rt->description }}
                                    </div>
                                    <div style="font-size:0.68rem;color:var(--slate-400);margin-top:2px;">
                                        {{ \Carbon\Carbon::parse($rt->repair_date)->format('M d, Y') }}
                                    </div>
                                </div>
                                <span style="font-size:0.62rem;font-weight:700;text-transform:uppercase;padding:0.15rem 0.5rem;border-radius:99px;background:{{ $sc['bg'] }};color:{{ $sc['color'] }};flex-shrink:0;">
                                    {{ ucfirst(str_replace('_',' ',$rt->status)) }}
                                </span>
                            </div>
                        @empty
                            <p style="font-size:0.8rem;color:var(--slate-400);font-style:italic;text-align:center;padding:0.75rem 0;margin:0;">
                                No repair tickets yet.
                            </p>
                        @endforelse
                        <button type="button" class="btn-hero btn-repair w-100 mt-3" style="justify-content:center;"
                                data-bs-toggle="modal" data-bs-target="#repairModal">
                            <i class="bi bi-plus-lg"></i> New Repair Ticket
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


{{-- ══════════════════════════════════════════════
     REPAIR TICKET MODAL — Premium Design
══════════════════════════════════════════════ --}}
<div class="modal fade" id="repairModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="border-radius:16px;overflow:hidden;font-family:'Montserrat',sans-serif;border:none;box-shadow:0 20px 60px rgba(15,23,42,0.18);">

            {{-- Cyan gradient header --}}
            <div style="background:linear-gradient(135deg,#0c4a6e 0%,#0891b2 100%);padding:1.25rem 1.5rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;">
                <div style="display:flex;align-items:center;gap:0.75rem;">
                    <div style="width:40px;height:40px;border-radius:10px;background:rgba(255,255,255,.12);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                        <i class="bi bi-tools" style="color:#67e8f9;font-size:1.1rem;"></i>
                    </div>
                    <div>
                        <div style="font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:rgba(255,255,255,.5);">New</div>
                        <div style="font-size:1rem;font-weight:800;color:#fff;letter-spacing:-.02em;line-height:1.2;">Repair Ticket</div>
                    </div>
                </div>
                {{-- Job context pill --}}
                <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
                    <div style="display:flex;align-items:center;gap:0.4rem;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);border-radius:99px;padding:0.3rem 0.85rem;">
                        <i class="bi bi-briefcase" style="color:#93c5fd;font-size:0.75rem;"></i>
                        <span style="font-size:0.75rem;font-weight:700;color:#fff;">{{ $job->job_number_name }}</span>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" style="opacity:.6;"></button>
                </div>
            </div>

            {{-- Address context bar --}}
            <div style="background:#0c4a6e;padding:0.55rem 1.5rem;display:flex;align-items:center;gap:0.65rem;border-bottom:1px solid rgba(255,255,255,.08);">
                <i class="bi bi-geo-alt-fill" style="color:rgba(255,255,255,.4);font-size:0.72rem;flex-shrink:0;"></i>
                <span style="font-size:0.72rem;color:rgba(255,255,255,.55);font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                    {{ $job->job_address_street_address }}
                    @if($job->job_address_street_address_line_2), {{ $job->job_address_street_address_line_2 }}@endif,
                    {{ $job->job_address_city }}, {{ $job->job_address_state }} {{ $job->job_address_zip_code }}
                </span>
                <span style="margin-left:auto;font-size:0.68rem;font-weight:700;background:rgba(59,130,246,.2);color:#93c5fd;padding:0.15rem 0.55rem;border-radius:99px;border:1px solid rgba(59,130,246,.3);flex-shrink:0;">
                    Job
                </span>
            </div>

            {{-- Body --}}
            <div class="modal-body" style="background:var(--slate-100);padding:0;">

                @if(session('repair_success'))
                    <div style="margin:1rem 1.25rem 0;background:#ecfdf5;border:1.5px solid #6ee7b7;border-radius:10px;padding:.75rem 1rem;display:flex;align-items:center;gap:.6rem;font-size:.82rem;color:#065f46;">
                        <i class="bi bi-check-circle-fill"></i>
                        <span>{{ session('repair_success') }}</span>
                    </div>
                @endif

                <form action="{{ route('repair-tickets.store') }}" method="POST"
                      enctype="multipart/form-data" id="rtFormJob">
                    @csrf
                    <input type="hidden" name="reference_type" value="job">
                    <input type="hidden" name="reference_id"   value="{{ $job->id }}">
                    {{-- Status siempre open al crear — el crew lo actualiza desde el móvil --}}
                    <input type="hidden" name="status" value="open">

                    <div style="padding:1.25rem 1.5rem;display:flex;flex-direction:column;gap:1.1rem;">

                        {{-- Step 1: Date --}}
                        <div>
                            <div class="rt-step-head">
                                <div class="rt-step-num"><span>1</span></div>
                                <span class="rt-step-label">Schedule</span>
                            </div>
                            <div>
                                <label class="rt-label">Repair Date</label>
                                <input type="date" name="repair_date" class="rt-ctrl"
                                       value="{{ date('Y-m-d') }}" required>
                            </div>
                        </div>

                        <hr class="rt-divider">

                        {{-- Step 2: Description --}}
                        <div>
                            <div class="rt-step-head">
                                <div class="rt-step-num"><span>2</span></div>
                                <span class="rt-step-label">Damage Description</span>
                            </div>
                            <textarea name="description" class="rt-ctrl" rows="4"
                                      placeholder="Describe the damage or issue found in detail…"
                                      required></textarea>
                            <div style="display:flex;justify-content:flex-end;margin-top:0.3rem;">
                                <span style="font-size:0.65rem;color:var(--slate-400);">
                                    <span style="color:var(--danger);">*</span> Required
                                </span>
                            </div>
                        </div>

                        <hr class="rt-divider">

                        {{-- Step 3: Photos — multi-file drop zone --}}
                        <div>
                            <div class="rt-step-head">
                                <div class="rt-step-num"><span>3</span></div>
                                <span class="rt-step-label">
                                    Photos
                                    <span style="font-size:0.68rem;font-weight:500;text-transform:none;letter-spacing:0;color:#94a3b8;margin-left:4px;">(optional)</span>
                                </span>
                            </div>

                            {{-- Drop zone --}}
                            <div id="rtDropZone"
                                 onclick="document.getElementById('rtFileInputJob').click()"
                                 ondragover="rtDragOver(event)"
                                 ondragleave="rtDragLeave(event)"
                                 ondrop="rtDrop(event)"
                                 style="border:2px dashed #cbd5e1;border-radius:12px;padding:1.5rem;text-align:center;cursor:pointer;transition:border-color .2s,background .2s;background:#f8fafc;">
                                <i class="bi bi-cloud-arrow-up" style="font-size:1.8rem;color:#94a3b8;display:block;margin-bottom:0.5rem;"></i>
                                <div style="font-size:0.8rem;font-weight:600;color:#64748b;">Click or drag photos here</div>
                                <div style="font-size:0.7rem;color:#94a3b8;margin-top:0.2rem;">JPG, PNG, WEBP, PDF — multiple files allowed</div>
                                <input type="file" id="rtFileInputJob" name="photos[]"
                                       accept="image/*,.pdf" multiple
                                       style="display:none;"
                                       onchange="rtHandleFiles(this.files)">
                            </div>

                            {{-- Preview grid --}}
                            <div id="rtPreviewGrid"
                                 style="margin-top:0.75rem;display:flex;flex-wrap:wrap;gap:0.5rem;display:none;">
                            </div>
                        </div>

                        {{-- Footer --}}
                        <div style="display:flex;align-items:center;justify-content:space-between;padding-top:0.75rem;border-top:1.5px solid var(--slate-200);margin-top:0.25rem;">
                            <a href="{{ route('repair-tickets.index', ['ref_type'=>'job','ref_id'=>$job->id]) }}"
                               style="font-size:0.76rem;font-weight:600;color:var(--repair);text-decoration:none;display:flex;align-items:center;gap:0.3rem;opacity:.75;transition:opacity .15s;"
                               onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=.75">
                                <i class="bi bi-clock-history"></i>
                                History ({{ $job->repairTickets?->count() ?? 0 }})
                            </a>
                            <button type="submit" class="btn-rt-submit">
                                <i class="bi bi-send-check"></i> Submit Ticket
                            </button>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// ── Multi-photo upload ──────────────────────────────────────
let rtFiles = [];

function rtHandleFiles(incoming) {
    Array.from(incoming).forEach(file => {
        rtFiles.push(file);
        rtRenderPreview(file, rtFiles.length - 1);
    });
    rtSyncInput();
    const dz = document.getElementById('rtDropZone');
    dz.style.borderColor = '#0891b2';
    dz.style.background  = '#f0fdff';
}

function rtRenderPreview(file, index) {
    const grid = document.getElementById('rtPreviewGrid');
    grid.style.display = 'flex';

    const wrap = document.createElement('div');
    wrap.id = 'rt-prev-' + index;
    wrap.style.cssText = 'position:relative;width:72px;height:72px;border-radius:8px;overflow:hidden;border:1.5px solid #e2e8f0;flex-shrink:0;';

    const isPdf = file.type === 'application/pdf';
    if (isPdf) {
        wrap.style.background = '#f1f5f9';
        wrap.innerHTML = `
            <div style="width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;">
                <i class="bi bi-file-pdf-fill" style="font-size:1.3rem;color:#ef4444;"></i>
                <span style="font-size:0.52rem;font-weight:600;color:#64748b;width:90%;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${file.name}</span>
            </div>`;
    } else {
        const img = document.createElement('img');
        img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
        img.src = URL.createObjectURL(file);
        wrap.appendChild(img);
    }

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.innerHTML = '<i class="bi bi-x"></i>';
    btn.style.cssText = 'position:absolute;top:2px;right:2px;width:18px;height:18px;border-radius:50%;background:rgba(15,23,42,.7);border:none;color:#fff;font-size:0.6rem;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;line-height:1;';
    btn.onclick = () => rtRemoveFile(index);
    wrap.appendChild(btn);

    grid.appendChild(wrap);
}

function rtRemoveFile(index) {
    rtFiles[index] = null;
    const el = document.getElementById('rt-prev-' + index);
    if (el) el.remove();
    if (rtFiles.every(f => f === null)) {
        const dz = document.getElementById('rtDropZone');
        dz.style.borderColor = '#cbd5e1';
        dz.style.background  = '#f8fafc';
        document.getElementById('rtPreviewGrid').style.display = 'none';
    }
    rtSyncInput();
}

function rtSyncInput() {
    const dt = new DataTransfer();
    rtFiles.filter(Boolean).forEach(f => dt.items.add(f));
    document.getElementById('rtFileInputJob').files = dt.files;
}

function rtDragOver(e) {
    e.preventDefault();
    e.currentTarget.style.borderColor = '#0891b2';
    e.currentTarget.style.background  = '#f0fdff';
}
function rtDragLeave(e) {
    if (!rtFiles.filter(Boolean).length) {
        e.currentTarget.style.borderColor = '#cbd5e1';
        e.currentTarget.style.background  = '#f8fafc';
    }
}
function rtDrop(e) {
    e.preventDefault();
    rtHandleFiles(e.dataTransfer.files);
}

// Reset drop zone cuando se cierra el modal
document.getElementById('repairModal').addEventListener('hidden.bs.modal', function () {
    rtFiles = [];
    document.getElementById('rtPreviewGrid').innerHTML = '';
    document.getElementById('rtPreviewGrid').style.display = 'none';
    document.getElementById('rtDropZone').style.borderColor = '#cbd5e1';
    document.getElementById('rtDropZone').style.background  = '#f8fafc';
    document.getElementById('rtFormJob').reset();
});

function confirmJobDelete(id) {
    Swal.fire({
        title: 'Delete Job Request?',
        text: 'This will permanently delete the job and all related data.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#334155',
        confirmButtonText: 'Yes, delete it',
        cancelButtonText: 'Cancel',
        reverseButtons: true,
    }).then((result) => {
        if (result.isConfirmed) document.getElementById('delete-form-' + id).submit();
    });
}
</script>

@endsection